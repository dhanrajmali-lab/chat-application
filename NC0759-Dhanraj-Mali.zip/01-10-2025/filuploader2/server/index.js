import express from "express";
import upload from "./middleware/multer.js";
import { Worker } from "worker_threads";
import { Server } from "socket.io";
import http from "http";
import cors from "cors";

const app = express();

app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: "http://localhost:5173/",
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

io.on("connection", (socket) => {
  console.log("socket connected ");
});

// app.post('/upload', (req, res) => {
//   let uploadedBytes = 0;
//   const totalBytes = parseInt(req.headers['content-length'], 10);

//   const writeablestream=fs.createWriteStream('output.txt');

//   req.on('data', chunk => {
//     uploadedBytes += chunk.length;
//     console.log(`Received ${chunk.length} bytes of data.`);
//     console.log(chunk);
//     const progress = (uploadedBytes / totalBytes) * 100;
//     console.log(`Progress: ${progress.toFixed(2)}%`);

//     console.log("buffer :",Buffer.from(chunk))
//   });

// });

app.post("/upload",upload.single('file'),(req,res) => {

  if (!req.file) {
    return res.status(400).send("No file uploaded.");
  }

  const {name} = req.body;

  const filePath = req.file.path;

  const worker = new Worker("./middleware/worker.js", {
    workerData: { filePath ,name},
  });

  worker.on("message", (message) => {
    if (message.type === "progress") {

          console.log(message.progress)
      io.emit("progress", { progress: message.progress });
    } else if (message.type === "complete") {
      io.emit("complete", {
        message: "file is uploaded",
        filename: req.file.originalname,
      });
    }
  });

  worker.on("error", (err) => {
    console.error("Worker error:", err);
    res.status(500).send("Error processing file.");
  });

  worker.on("exit", (code) => {
    if (code !== 0) {
      console.error(`Worker exited with code ${code}`);
    }
  });

  res.status(202).send("file is uploaded.");
});

server.listen(5000, () => {
  console.log("Server listening on port 3000");
});