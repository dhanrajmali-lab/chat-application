import { parentPort, workerData } from "worker_threads";
import fs from "fs";
import csv from "csv-parser";

const filePath = workerData.filePath;
const name  = workerData.name;

// let totalRows = 0;
// let processedRows = 0;

// fs.createReadStream(filePath)
//   .pipe(csv())
//   .on("data", () => totalRows++)
//   .on("end", () => {
//     processFile();
//   });

// function processFile() {

//   fs.createReadStream(filePath)
//     .pipe(csv())
//     .on("data", (row) => {
//       processedRows++;
//       if (processedRows % 100 === 0) {
//         const progress = Math.round((processedRows / totalRows) * 100);
//         parentPort.postMessage({ type: "progress", progress });

//       }
//     })
//     .on("end", () => {
//       parentPort.postMessage({ type: "complete" });
//     })
//     .on("error", (err) => {
//       console.error("Error processing file:", err);
//     });

// }


// second way
const readablestream=fs.createReadStream(filePath,{
    encoding: "utf-8",
});

const writeablestream=fs.createWriteStream(`./uploads/${name}`);

let totalLength=0;
let processdata=0

// console.log("files", filePath)

fs.stat(filePath, (err, stats) => {
    if (err) {
      if (err.code === 'ENOENT') {
        return res.status(404).send('File not found.');
      }
      console.error('Error getting file stats:', err);
      return res.status(500).send('Server error.');
    }   
     totalLength = stats.size;

    console.log(totalLength)
  });

readablestream.on('data', (chunk) => {
  // console.log(chunk)
  processdata += chunk.length
 
    const progress = Math.round((processdata / totalLength) * 100);
   parentPort.postMessage({ type: "progress", progress });
 
   Buffer.from(chunk)

  });

readablestream.on('end', () => {
  fs.unlinkSync(filePath);
   parentPort.postMessage({ type: "complete" });
});

readablestream.pipe(writeablestream);

readablestream.on("error",(error)=> console.log("error:",error));
writeablestream.on("error",(error)=> console.log("error:",error));