import { io } from "socket.io-client";
import "./App.css";
import { useEffect } from "react";
import { useState } from "react";
import axios from "axios";

function App() {
  let [progresss, setProgress] = useState(0);
  const [file, setfile] = useState(null);
  const [done, setDone] = useState([]);
  const [name , setName] = useState('')
  const socket = io("http://localhost:5000");

  useEffect(() => {
    socket.on("progress", (data) => {
      setProgress(data.progress);
    });

    socket.on("complete", ({ message, filename }) => {
      console.log(message);
      setDone((prev) => [...prev, filename]);
      setProgress(100);
    });
  }, []);

  const handleFileChange = (event) => {

    
    setfile(event.target.files[0]);
    const selectedFile = event.target.files[0]; 
    setName(selectedFile.name)
    setProgress(0);
  };

  const handlesubmit = () => {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("name",name)

    axios
      .post("http://localhost:5000/upload", formData)
      .then((res) => {
        console.log(res);
      })
      .catch((er) => {
        console.log(er);
      });
  };

  return (
    <>
      <div>
        <h1> Add files </h1>
        <input type="file" onChange={handleFileChange} />
        <button onClick={handlesubmit}>submit</button>
      </div>

      <div>
        <progress max={100} value={progresss} />
        <span> {progresss} %</span>
      </div>

      <div>
        <h3>completed</h3>
        {done.map((item, i) => {
          return <p key={i}>{item}</p>;
        })}
      </div>
    </>
  );
}

export default App;
