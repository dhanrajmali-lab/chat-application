import { Op } from "sequelize";
import { ticket, booking } from "../model/ticketModel.js";

const ticketbook = async (req, res) => {
  try {
    const { eventname, slot } = req.body;
     let timing = "0";
        if(slot == "1")
        {
            timing ="9 AM"
        }
        else if(slot == "2")
        {
            timing ="12 PM"

        }
        else if(slot == "3")
        {
            timing ="2 PM"

        }
        else if(slot == "4")
        {
            timing ="4 PM"

        }
   
        

    const bookby = res.data.finduser.name;

    booking.create(
      {
        eventname,
        slot,
        timing: timing,
        bookby: bookby,
        ticketId: req.params.id,
      },
      {
        include: [{ model: ticket, as: "ticket" }],
      }
    );

    const data = await ticket.findOne({ where: { id: req.params.id } });

    const d = data.availableticket - 1;

    await ticket.update(
      { availableticket: d },
      { where: { id: req.params.id } }
    );

    res.status(200).json({ msg: "ticket is booekd" });
  } catch (error) {
    res
      .status(500)
      .json({ msg: "something wrong in ticketbooking", er: error });
  }
};

const cancelbook = async (req, res) => {
  try {
    const bookby = res.data.finduser.name;

       
     
     await booking.destroy({ where: { id: req.params.id } });


    const data = await ticket.findOne({ where: { createdBy:bookby } });
  

    const d =Number( data.availableticket) + 1;

        console.log(d)
    await ticket.update(
      { availableticket: d },
      { where: { createdBy:bookby }}
    );

    res.status(200).json({ msg: "ticket is cancel" });
  } catch (error) {
    res
      .status(500)
      .json({ msg: "something wrong in ticket cancel", er: error });
  }
};

export { ticketbook, cancelbook };
