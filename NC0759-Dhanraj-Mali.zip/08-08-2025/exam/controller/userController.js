import user from '../model/userModel.js'
import bcrypt from 'bcrypt'
import jwt from "jsonwebtoken"
const privatekey="123456789"
const register =async (req,res) => {

    try {

        const {name,email,password,role} = req.body

        if(role != 'admin')
        {
            const hasspassword =bcrypt.hashSync(password,5)

            await user.create({name,email,password:hasspassword,role})
           res.status(200).json({msg:"user is created"})
        }
        else{
        res.status(500).json({msg:"admin is already exist"})

        }
        
    } catch (error) {
        res.status(500).json("something wrong in register controller",error)
    }
    
}



const login =async (req,res) => {

    try {

        const {email,password} = req.body


         const finduser =  await user.findOne({where:{email:email}})

            if(finduser == null)
            {
             res.status(404).json({msg:"user is not found"})

            }

            if(bcrypt.compareSync(password,finduser.password) == true)
            {

              const token = jwt.sign({finduser},privatekey,{expiresIn:"1h"})
                  


              res.status(200).json({msg:"user is login", data:token})

            }
            else{

             res.status(400).json({msg:"password is not matched"})

            }
        
    } catch (error) {
        res.status(500).json("something wrong in register controller",error)
    }
    
}


export {login,register}