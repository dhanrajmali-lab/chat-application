import event from '../model/eventsModel.js'


const createEvent = async (req,res)=>{

    try {
        const {eventname,Totalslot,duration,organizername}= req.body;
        
        await event.create({eventname,Totalslot,duration,organizername})


        res.status(200).json({msg:"event is created"})

    } catch (error) {

        res.status(500).json({msg:"something wrong in create event",er:error})
        
    }
}


const ceditEvent = async (req,res)=>{

    try {
        const body= req.body;
        
        console.log(body)
       await event.update(body,{where:{id:req.params.id}})

        res.status(200).json({msg:"event is updated"})

    } catch (error) {

        res.status(500).json({msg:"something wrong in update event",er:error})
        
    }
}


const deleteEvent = async (req,res)=>{

    try {
     
       await event.destroy({where:{id:req.params.id}})


        res.status(200).json({msg:"event is deleted"})

    } catch (error) {

        res.status(500).json({msg:"something wrong in delete event",er:error})
        
    }
}


const getEventAll = async (req,res)=>{

    try {
     
       const events= await event.findAll()

        res.status(200).json({data:events})

    } catch (error) {

        res.status(500).json({msg:"something wrong in delete event",er:error})
        
    }
}

const getEventByname = async (req,res)=>{

    try {
     
            const name=res.data.finduser.name
       const events= await event.findOne({where:{organizername:name}})

        res.status(200).json({data:events})

    } catch (error) {

        res.status(500).json({msg:"something wrong in delete event",er:error})
        
    }
}


export {createEvent,ceditEvent,deleteEvent,getEventAll,getEventByname}