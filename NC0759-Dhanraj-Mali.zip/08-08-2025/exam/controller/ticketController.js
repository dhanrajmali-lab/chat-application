import {ticket} from '../model/ticketModel.js';


const createTicket =async (req,res) => {
    
    try {
        const {eventname,price,slot,timing,ticketlimit} = req.body;    

        const createdby =res.data.finduser.name
        console.log(timing)

        await ticket.create({eventname,price,slot,timing,ticketlimit,availableticket:ticketlimit,createdby:createdby})

        res.status(200).json({msg:"Ticket is created"})

    } catch (error) {
        res.status(500).json({msg:"something wrong in createTicket",er:error})
    }
}



const editTicket =async (req,res) => {
    
    try {
    const {eventname,price,slot,timing} = req.body;    

        await ticket.update({eventname,price,slot,timing},{where:{id:req.params.id}})

        res.status(200).json({msg:"Ticket is created"})

    } catch (error) {
        res.status(500).json({msg:"something wrong in createTicket",er:error})
    }
}

const getAllTicket =async (req,res) => {
    
    try {
    

        const data=await ticket.findAll()

        res.status(200).json({data})

    } catch (error) {
        res.status(500).json({msg:"something wrong in createTicket",er:error})
    }
}


export {createTicket,editTicket,getAllTicket}