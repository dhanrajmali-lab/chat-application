import express from 'express'
import dotenv from "dotenv";
import userRouter from './routes/userRouter.js';
import eventRouter from './routes/eventRouter.js';
import tokenVerify from './middleware/jwtVerify.js';
import ticketRouter from './routes/ticketRouter.js';
import bookRouter from './routes/bookRouter.js';
dotenv.config();
const app=express();

app.use(express.json())
app.use(express.urlencoded())


app.get('/',(req,res)=>{
    res.send("working")
})

app.use('/user',userRouter)
app.use('/event',tokenVerify,eventRouter)
app.use('/ticket',tokenVerify,ticketRouter)
app.use('/ticketbook',tokenVerify,bookRouter)




app.listen(process.env.PORT,()=>{
    console.log("app is running ",process.env.PORT)
})