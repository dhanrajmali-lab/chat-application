import { DataTypes } from 'sequelize'
import sequelize from '../config/db.js'
const event = sequelize.define('event',{

    eventname:{
        type:DataTypes.STRING,
        allowNull:false
    },
    Totalslot:{
        type:DataTypes.STRING,
        allowNull:false,
    },
    duration:{
        type:DataTypes.STRING,
        allowNull:false,
    },

    organizername:{
        type:DataTypes.STRING,
        allowNull:false,
    }
})


await event.sync()
.then(()=>{console.log("event table is created")})
.catch((er)=>{console.log("event table is not creates",er)})

export default event