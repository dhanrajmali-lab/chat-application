import { DataTypes } from 'sequelize'
import sequelize from '../config/db.js'

const ticket = sequelize.define('ticket',{

    eventname:{
        type:DataTypes.STRING,
        allowNull:false
    },
     price:{
        type:DataTypes.INTEGER,
        allowNull:false
    },
    slot:{
        type:DataTypes.STRING,
        allowNull:false,
    },
    timing:{
        type:DataTypes.STRING,
        allowNull:false,
    },
    ticketlimit:{
        type:DataTypes.STRING,
        allowNull:false
    },
    availableticket:{
        type:DataTypes.STRING,
        allowNull:false
    },
    createdby:{
        type:DataTypes.STRING,
        allowNull:false,
    }
})



const booking = sequelize.define('booking',{
    eventname:{
        type:DataTypes.STRING,
        allowNull:false
    },
    slot:{
        type:DataTypes.STRING,
        allowNull:false,
    },
    timing:{
        type:DataTypes.STRING,
        allowNull:false,
    },
    bookby:{
        type:DataTypes.STRING,
        allowNull:false,
    },
 
})


ticket.hasMany(booking)
booking.belongsTo(ticket)


await ticket.sync()
.then(()=>{console.log("event table is created")})
.catch((er)=>{console.log("event table is not creates",er)})

await booking.sync()
.then(()=>{console.log("event table is created")})
.catch((er)=>{console.log("event table is not creates",er)})


export{ticket,booking} 