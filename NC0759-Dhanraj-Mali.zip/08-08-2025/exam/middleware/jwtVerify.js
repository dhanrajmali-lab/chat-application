import jwt from 'jsonwebtoken'
const privatekey="123456789"

const tokenVerify = async (req,res,next) => {

    try {
     const token =req.headers.authorization.split(" ")[1];


    if(! token)
    {
    res.status(400).json({msg:"access denied"})
    }
    else{
       res.data= jwt.verify(token,privatekey)
       next()
    }
    } catch (error) {

        res.status(500).json({msg:"something wrong in jwt",er:error})
        
    }

}

export default tokenVerify;