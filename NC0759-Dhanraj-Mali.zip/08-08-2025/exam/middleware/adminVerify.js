
const isAdmin=(req,res,next)=>{

        if(res.data.finduser.role == "admin")
        {
            next()
        }
        else{
            res.status(500).json({msg:"only admin allow"})

        }
}


export default isAdmin