
const isOrganizer=(req,res,next)=>{

        if(res.data.finduser.role == "organizer" )
        {
            next()
        }
        else{
            res.status(500).json({msg:"only organizer allow"})

        }
}


export default isOrganizer