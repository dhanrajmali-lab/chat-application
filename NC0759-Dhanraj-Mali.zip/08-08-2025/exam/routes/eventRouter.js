import  {createEvent,ceditEvent,deleteEvent,getEventAll,getEventByname} from '../controller/eventsController.js'
import express from "express"
const eventRouter=express.Router();
import isAdmin from '../middleware/adminVerify.js';
import isOrganizer from '../middleware/organizrVerify.js';

eventRouter.get('/allevetn',getEventAll)

eventRouter.get('/myevent',isOrganizer,getEventByname)

eventRouter.post('/createevent',isAdmin,createEvent)

eventRouter
    .route('/:id')
    // .get(isAdmin,getEvent)
    .put(isAdmin,ceditEvent)
    .delete(isAdmin,deleteEvent)


export default eventRouter
