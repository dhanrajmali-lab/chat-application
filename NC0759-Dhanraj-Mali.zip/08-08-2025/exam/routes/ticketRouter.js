import {createTicket,editTicket,getAllTicket} from '../controller/ticketController.js'
import express from "express"
const ticketRouter=express.Router();
import isAdmin from '../middleware/adminVerify.js';
import isOrganizer from '../middleware/organizrVerify.js';


ticketRouter.post('/create',isOrganizer,createTicket);
ticketRouter.put('/:id',isOrganizer,editTicket);
ticketRouter.get('/',getAllTicket);




export default ticketRouter