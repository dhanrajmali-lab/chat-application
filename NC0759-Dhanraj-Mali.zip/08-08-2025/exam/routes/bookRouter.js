import  {ticketbook,cancelbook} from '../controller/bookingController.js'

import express from "express"
const bookRouter=express.Router();
import isAdmin from '../middleware/adminVerify.js';
import isOrganizer from '../middleware/organizrVerify.js';


bookRouter.post('/book/:id',ticketbook)
bookRouter.delete('/cancel/:id',cancelbook)


export default bookRouter;