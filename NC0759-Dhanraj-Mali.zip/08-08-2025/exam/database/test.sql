-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 08, 2025 at 01:05 PM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
CREATE TABLE IF NOT EXISTS `bookings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `eventname` varchar(255) NOT NULL,
  `slot` varchar(255) NOT NULL,
  `timing` varchar(255) NOT NULL,
  `bookby` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `ticketId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticketId` (`ticketId`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `eventname`, `slot`, `timing`, `bookby`, `createdAt`, `updatedAt`, `ticketId`) VALUES
(1, 'html', '1', '9am', 'shubham', '2025-08-08 12:07:58', '2025-08-08 12:07:58', 1),
(12, 'html', '1', '9am', 'shubham', '2025-08-08 12:43:22', '2025-08-08 12:43:22', 1),
(15, 'html', '1', '9am', 'shubham', '2025-08-08 12:48:42', '2025-08-08 12:48:42', 1),
(16, 'html', '1', '9am', 'shubham', '2025-08-08 12:48:43', '2025-08-08 12:48:43', 1),
(18, 'html', '1', '9 AM', 'shubham', '2025-08-08 12:56:26', '2025-08-08 12:56:26', 1),
(19, 'html', '2', '12 PM', 'shubham', '2025-08-08 12:56:40', '2025-08-08 12:56:40', 1),
(20, 'css', '2', '12 PM', 'sahil', '2025-08-08 13:02:31', '2025-08-08 13:02:31', 2),
(21, 'css', '2', '12 PM', 'sahil', '2025-08-08 13:03:53', '2025-08-08 13:03:53', 2),
(22, 'css', '2', '12 PM', 'sahil', '2025-08-08 13:04:10', '2025-08-08 13:04:10', 2);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `eventname` varchar(255) NOT NULL,
  `Totalslot` varchar(255) NOT NULL,
  `duration` varchar(255) NOT NULL,
  `organizername` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `eventname`, `Totalslot`, `duration`, `organizername`, `createdAt`, `updatedAt`) VALUES
(1, 'html', '4', '2h', 'raj', '2025-08-08 10:31:13', '2025-08-08 10:31:13'),
(2, 'css', '4', '3h', 'shubham', '2025-08-08 12:59:17', '2025-08-08 12:59:17');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `eventname` varchar(255) NOT NULL,
  `price` int NOT NULL,
  `slot` varchar(255) NOT NULL,
  `timing` varchar(255) NOT NULL,
  `ticketlimit` varchar(255) NOT NULL,
  `availableticket` varchar(255) NOT NULL,
  `createdby` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `eventname`, `price`, `slot`, `timing`, `ticketlimit`, `availableticket`, `createdby`, `createdAt`, `updatedAt`) VALUES
(1, 'html', 200, '1-4', '9PM', '200', '194', 'shubham', '2025-08-08 12:07:44', '2025-08-08 12:56:40'),
(2, 'css', 200, '1-4', '8 Am To 8 PM', '50', '47', 'shubham', '2025-08-08 13:01:21', '2025-08-08 13:04:10');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','organizer','user') NOT NULL DEFAULT 'user',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `createdAt`, `updatedAt`) VALUES
(1, 'raj', 'raj@gmail.com', '$2b$05$FmH6udHoomTm9dHkn..0c.qaF5JQbs3T999euFwRuPsozmhAoriEq', 'admin', '2025-08-08 10:30:16', '2025-08-08 10:30:16'),
(2, 'shubham', 'shubham@gmail.com', '$2b$05$CxT.E7r9uxUBnvy9G/hNTeRkv4hClgbAukZ43MWd50F96tXJB20Qu', 'organizer', '2025-08-08 10:30:30', '2025-08-08 10:30:30'),
(3, 'sahil', 'sahil@gmail.com', '$2b$05$AvasknEEBgJ29rc0y.1p.ur7Fn/dEVaXNA/PZhYKWI2VYDL/9TjQW', 'user', '2025-08-08 11:09:08', '2025-08-08 11:09:08');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`ticketId`) REFERENCES `tickets` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
