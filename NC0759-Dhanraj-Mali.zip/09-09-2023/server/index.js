import express from "express";
const app = express();
import { Server } from "socket.io";
import http from "http";
import multfile from "./middleware/multer.js";
import fs from "fs";
import { Readable } from "stream";
import cors from "cors";

app.use(cors());
app.use(express.json());
app.use(express.urlencoded());

const server = http.createServer(app);
const io = new Server(server, {
  cors: "http://http://localhost:5173/",
});

app.get("/", (req, res) => {
  res.send("working");
});

app.post("/upload", multfile, (req, res) => {
  console.log(req.file);
  if (!req.file) {
    return res.status(400).send("No file uploaded.");
  }
  const fileName = req.file.originalname;
  const writeStream = fs.createWriteStream(`./uploads/${fileName}`);
  const bufferStream = Readable();
  bufferStream.push(req.file.buffer);
  bufferStream.push(null);

  let uploadedBytes = 0;
  const totalBytes = req.file.buffer.length;

  
  bufferStream.on("data", (chunk) => {
    uploadedBytes += chunk.length;
    console.log("chunks length", uploadedBytes);
    console.log("total", totalBytes);
    const progress = (uploadedBytes / totalBytes) * 100;
    console.log("pro", progress);
    io.emit("upload_progress", { fileName, progress });
  });

  bufferStream.pipe(writeStream);

  writeStream.on("finish", () => {
    io.emit("upload_complete", { fileName });
    res.send("File uploaded successfully!");
  });
});

server.listen(5000, () => {
  console.log("server is runing on port number:5000");
});
