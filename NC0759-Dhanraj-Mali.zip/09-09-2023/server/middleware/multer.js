import multer from "multer";

const storage= multer.memoryStorage()

const upload = multer({storage:storage})
const multfile =upload.single('file')

export default multfile