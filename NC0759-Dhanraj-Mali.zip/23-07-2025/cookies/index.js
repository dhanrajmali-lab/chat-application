const express = require('express');
const app = express();
var session = require('express-session');
const cookieParser = require('cookie-parser');
app.use(cookieParser());

app.get('/', function(req, res){
   res.cookie('name', 'express').send('cookie set'); //Sets name = express
});

app.get('/cookie',(req,res)=>{
    console.log(req.cookies)
    res.send(req.cookies)
})

app.get('/clearcookie', function(req, res){
   res.clearCookie('name');
   res.send('cookie name cleared');
});

app.use(session({
   secret: 'sample-secret',
   resave: false,
   saveUninitialized: false
}));

app.get('/session', function(req, res){
   if(req.session.page_views){
      req.session.page_views++;
      res.send("You visited this page " + req.session.page_views + " times");
   } else {
      req.session.page_views = 1;
      res.send("Welcome to this page for the first time!");
   }
});

app.listen(3000);