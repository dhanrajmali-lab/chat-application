const movies= require('../model/movies')


function getallmovie(req, res) {

    if (movies) {
        res.status(200).json({ data: movies })
    }
    else {
        res.status(404).json({ msg: "not found" })
    }

}

function getmoviebyid(req, res) {
    const id = req.params.id;
    const movie = movies.find((item) => item.id == id)
    if (movie) {
        res.status(200).json({ data: movie })
    }
    else {
        res.status(404).json({ msg: "movie is not found" });
    }
}



function patchmoviebyid(req, res) {
    const id = req.params.id;
    const data = req.body;

    const idx = movies.findIndex(obj => obj.id == id)

    console.log(idx)
    if (idx == -1) {
        res.status(404).json({ error: "not found" });
    }
    else {

        const item = movies.find(obj => obj.id == id);

        console.log(item)

        for (let x in data) {
            item[x] = data[x]
        }
        res.status(201).json({ msg: "fileds are successfully added", data:item});
    }
}


function postaddnewmovie(req, res) {
        const data = req.body;
          const idx = movies.findIndex(obj => obj.id == data.id)

        if(idx == -1)
        {
            movies.push(data)

        res.status(201).json({msg:"movie is added",data:data})
        }
        else{
              res.status(400).json({error:"movie is alreay exist"})
              
        } 
}

function deletebyid(req, res) {

    const idx = movies.findIndex((obj) => obj.id == req.params.id);
    console.log(idx)

    if (idx == -1) {
        res.status(404).json({error:"movie is not found"})
    }
    else{
        movies.splice(idx, 1);
        res.status(200).json({msg:"deleted" +req.params.id+ "movie"})
       
    }
}

function putmovie(req, res) {

    const item = req.body;
   
        const idx = movies.findIndex(obj => obj.id == item.id);
        if (idx == -1) {

                res.status(404).json({error:"not found"})
        }
        else{
             movies[idx] = item;
              res.status(200).json({msg:"movie is updated",data:item})
   
        }
}


module.exports = { getmoviebyid, getallmovie, patchmoviebyid, postaddnewmovie, deletebyid, putmovie }