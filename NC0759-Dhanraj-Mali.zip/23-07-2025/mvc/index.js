const express = require('express')
const multer = require('multer');
const env = require('dotenv');
const app= express();
const upload=require('./middleware/multer')
env.config();
app.use(express.json());
app.use(express.urlencoded({extended:false}))
app.set('view engine', 'pug');
app.set('views','./views');
const movie = require('./routes/moives')



app.get('/',(req,res)=>{
    res.send("hello")
})


app.get('/image',(req,res)=>{
    res.render('image.pug')
})

app.post('/file',upload.single('image'),(req,res)=>{
    console.log(req.file)
    res.send("file is uploaded")

})



app.use('/movies', movie)

app.listen(process.env.PORT,()=>{
    console.log("app is runing on port number"+process.env.PORT)
})