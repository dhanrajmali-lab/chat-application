const multer = require('multer');

const storage=multer.diskStorage({
    destination:(req, file,call)=>{
        call(null,'uploads/');
    },
    filename:(req,file,call)=>{
        call(null,Date.now()+"-"+file.originalname);
    }
})

const upload=multer({storage});

module.exports=upload;