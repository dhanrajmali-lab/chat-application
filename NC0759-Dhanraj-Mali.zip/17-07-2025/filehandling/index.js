const fs= require('fs');

//Write file
/// creating file asynchronously
// fs.writeFile('test.txt',"using asychronous create file",'utf-8',(err)=>{
    
//         if(err)
//         {
//             console.log('error while creating fiel :',err);
//             return;
//         }
//         console.log("file is successfully created")

// })

// /// creating file synchronously
// try {
//     fs.writeFileSync('test1.txt',"using synchronous create fiel",'utf-8')
// } catch (error) {
    
//     console.log('Error for creating file',error);
// }




/// read file

// read file Asynchrounsly


// fs.readFile('test.txt','utf-8',(err,data)=>{

//             if(err)
//             {
//                 console.log('error for reading file',err);
//             }
//             console.log("content is :> ",data);
// })


// try {
//     const data=fs.readFileSync('test1.txt','utf-8');

//     console.log('content :>',data)
// } catch (error) {
    
//     console.log("error for reading file",error);
// }




// fs.appendFile('test.txt','hello world append in',(err)=>{
//     console.log('error',err);
// })


// try {
// fs.appendFileSync('test1.txt','hello is append in')
    
// } catch (error) {
//     console.log('error is coming',error)
// }


// fs.unlink('test.txt', (er)=>{
//     if(er)
//     {
//     console.log(er)

//     }
// })


// try {
// fs.unlinkSync('test1.txt')
    
// } catch (error) {
    
//     console.log(error)
// }