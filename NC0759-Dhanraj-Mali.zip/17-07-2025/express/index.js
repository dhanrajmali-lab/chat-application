const express = require('express');
const app = express();
const port = 8080;

app.get('/', (req, res) => {
  res.send('<h1> Home Page </h1>');
});

app.get('/about',(req,res)=>{
  res.send('<h1>About page</h1>')
});

app.get('/service',(req,res)=>{

    res.send('<h1> Service page </h1>')
});

// Route with HTML response
app.get('/html', (req, res) => {
  res.send(`
    <html>
      <head>
        <title>Express Routing</title>
        <style>
        *{
          padding:0px;
          margin:0px;
         }
          body { font-family: Arial, sans-serif;  }
          h1 { color:rgb(224, 228, 231); }
          p { margin-bottom: 20px;
              color:white;
          }
          div{
            width:100%;
            background-color:black;
            text-align:center;
          }
            a{
            color:crimson;
            }
        </style>
      </head>
      <body>
        <div>
        <h1>HTML Response from Express</h1>
        <p>This response was sent using Express routing.</p>
        <p>Try other routes: <a href="/">/</a> | <a href="/about">/about</a> | <a href="/service">/service</a></p>
        </div>
      </body>
    </html>
  `);
});
app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});

