const { error } = require('console');
const fs=require('fs');


const readablestream=fs.createReadStream('input.txt',{
    encoding: "utf-8",
    highWaterMark:15,
});


const writeablestream=fs.createWriteStream('output.txt');


readablestream.on('data', (chunk) => {
  console.log(`Received ${chunk.length} bytes of data.`);
  console.log(chunk);

  console.log("buffer :",Buffer.from(chunk))
});

readablestream.on('end', () => {
  console.log('No more data to read.');
});

readablestream.pipe(writeablestream);


readablestream.on("error",(error)=> console.log("error:",error));
writeablestream.on("error",(error)=> console.log("error:",error));

