const path=require('path');


console.log("dir:>",__dirname);
console.log("folder name:>",__filename);



const filepath=path.join("school","student","data.txt");
console.log(filepath)

const paarse=path.parse(filepath);
const basename=path.basename(filepath);
const resolve=path.resolve(filepath);
const extname=path.extname(filepath);
 const dirname=path.dirname(filepath);

const data={paarse,basename,resolve,extname,dirname};

console.log(data)
