setTimeout(() => {
    
    console.log("1")//code execute 
}, 3000);



const interval=setInterval(()=>{
    console.log("2")
},2000)


setImmediate(() => {
  console.log('This runs in the next iteration of the event loop');
});



setTimeout(() => {
  clearInterval(interval);
  console.log('Name interval stopped');
}, 8000);