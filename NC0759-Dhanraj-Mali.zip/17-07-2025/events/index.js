const event = require('events');
const { listeners } = require('process');

const emit= new event.EventEmitter();


emit.on('greet',()=>{

    console.log("hello world");
})

emit.emit('greet')


emit.on('user',(user)=>{

    console.log(`user name :${user.name}, user age :${user.age}`);
})

emit.emit('user',{name:"raj",age:20})
