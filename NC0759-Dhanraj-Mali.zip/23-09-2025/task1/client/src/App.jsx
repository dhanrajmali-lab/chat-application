import './App.css'
import {BrowserRouter as Router, Route,Routes} from "react-router-dom"
import Index from './pages/Index'
import Login from './components/login/Login'
import Registe from './components/singup/Registe'
  import { ToastContainer } from 'react-toastify';
import Admin from './pages/Admin'
import Addbook from './components/admin/Addbook'
import Listbook from './components/admin/Listbook'

function App() {

  return (
    <Router>
      <ToastContainer />

      <Routes>
        <Route path='/' element={<Login/>} />
        <Route path='/singup' element={<Registe/>} />
        <Route path='/index' element={<Index/>} />
        <Route path='/adminDashboard' element={<Admin/>} >
            <Route path='addbook' element={<Addbook/>}/>
            <Route path='listbook' element={<Listbook/>}/>

        </Route>


      </Routes>
    </Router>
  )
}

export default App
