import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import axios from 'axios'
const Login = () => {

    const [email,setEmail] = useState('')
    const [password,setPassword]=useState('')

      const navigate = useNavigate()


    const handleSubmit=(e)=>{
        e.preventDefault()

        console.log(email,password)

        axios.post('http://localhost:5000/user/login',{email,password})
        .then((res)=>{
            console.log(res.data.token)
            localStorage.setItem('token',res.data.token)
            toast.success(res.data.msg)
            
              if(res.data.user == 'admin')
              {
                navigate('/adminDashboard')
              }
              else 
              {
                navigate('/index')
              }
        })
        .catch((er)=>{
            console.log(er)
            toast.success("error")
        })
    }

    
  return (
  <div className="main">
        <div className="box">
          <form onSubmit={handleSubmit}>
            <div className="heading">
              <h1>Login Form</h1>
            </div>

            <div className="group">
              <label for="Email">Email </label>
              <input
                type="email"
                value={email}
                onChange={(e)=>setEmail(e.target.value)}
                required
              />
            </div>

            <div className="group">
              <label for="password">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e)=>setPassword(e.target.value)}
                required
              />
            </div>

            <div style={{ textAlign: "center" }}>
              <button type="submit" className="submit">
                Login
              </button>
            </div>
            
            <h4 className="link">
              <Link to="/singup">Singup now</Link>
            </h4>
          </form>
        </div>
      </div>
  )
}

export default Login