import axios from 'axios'
import React from 'react'
import { useState } from 'react'
import {toast} from 'react-toastify'

const Addbook = () => {


  const [title,setTitle]= useState('')
  const [author,setAuthor]=useState('')
  const [description,setDescription]= useState('')
  const [Total,setTotal]= useState('')
  const [image,setImage]=useState('')


  const handleImage=(e)=>{
    setImage(e.target.files[0]);
  }


  const handleSubmit =(e)=>{
    e.preventDefault();

    const form = new FormData();

    form.append('bookTitle',title);
    form.append('bookAuthor',author);
    form.append('bookDescription',description)
    form.append('Totalbooks',Total)
    form.append('image',image)


    console.log(form)

    axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('token')}`;
    axios.post('http://localhost:5000/book/add',form)
    .then((res)=>{
      console.log(res)

        toast.success('book is added')
        setTitle('')
        setAuthor('')
        setDescription('')
        setTotal('')
        setImage('')
      
    })
    .catch((er)=>{
      console.log(er)
    })
  }

  return (
    
    <div style={{
      width:'100%',
      display:'flex',
      justifyContent:'center',
      alignItems:'center'

    }}>
        

          <div className="main">
        <div className="box">
          <form onSubmit={handleSubmit}>
            <div className="heading">
              <h1>Add book</h1>
            </div>

            <div className="group">
              <label for="book name">Book Title </label>
              <input
                type="text"
                value={title}
                onChange={(e)=>setTitle(e.target.value)}
                required
              />
            </div>

            <div className="group">
              <label for="author">Book Author</label>
              <input
                type="text"
                value={author}
                onChange={(e)=>setAuthor(e.target.value)}
                required
              />
            </div>
             <div className="group">
              <label for="description">Book discription</label>
              <input
                type="text"
                value={description}
                onChange={(e)=>setDescription(e.target.value)}
                required
              />
            </div>
             <div className="group">
              <label for="image">Total Books</label>
              <input
                type="text"
                value={Total}
                onChange={(e)=>setTotal(e.target.value)}
                required
              />
            </div>

              <div className="group">
              <label for="image">Book Image</label>
              <input
                type="file"
                onChange={handleImage}
                required
              />
            </div>

            <div style={{ textAlign: "center" }}>
              <button type="submit" className="submit">
                add
              </button>
            </div>
            
         
          </form>
        </div>
      </div>
 

    </div>
   
  )
}

export default Addbook