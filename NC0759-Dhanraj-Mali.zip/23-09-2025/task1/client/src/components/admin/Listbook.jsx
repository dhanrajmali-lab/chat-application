import axios from "axios";
import React from "react";
import { useState } from "react";
import { useEffect } from "react";

const Listbook = () => {
  const [data, setData] = useState([]);
  useEffect(() => {
    axios.defaults.headers.common[
      "Authorization"
     ] = `Bearer ${localStorage.getItem("token")}`;
    axios
      .get("http://localhost:5000/book/getAll")
      .then((res) => {
        console.log(res.data);

        setData(res.data);
      })
      .catch((er) => {
        console.log(er);
      });
  }, []);


  const handleDelete =(id)=>{

    axios.delete(`http://localhost:5000/book/delete/${id}`)
    .then((res)=>{
      console.log(res)
      
    })
    .catch((er)=>{
      console.log(er)
    })
  }

  
  return (
    <>
      <div style={{
        width:'100%',
        display:'flex',
        justifyContent:'center',
        alignItems:'center'
       
      }}>
        <table border="1px solid black" style={{width:'80%',textAlign:'center'}}>
          <tr>
            <th>image</th>
            <th>Title</th>
            <th>description</th>
            <th>Author</th>
            <th>Total books</th>
            <th>current available</th>
            <th>borrow books</th>
            <th>action</th>

          </tr>

          {data.map((item)=>{
            return <tr>
                <td>  <img src={`http://localhost:5000/uploads/${item.bookImage}`} style={{width:'80px',height:'80px'}} /></td>
                <td>{item.bookTitle}</td>
                <td>{item.bookDescription}</td>
                <td>{item.bookAuthor}</td>
                <td>{item.Totalbooks}</td>
                <td>{item.currentAvailable}</td>
                <td>{item.borrowBooks}</td>
                <td> <button>edit</button> <button onClick={()=>handleDelete(item.id)}>delete</button> </td>
            </tr>
          })}
        </table>
      </div>
    </>
  );
};

export default Listbook;
