import React from 'react'
import {Link}from 'react-router-dom'

const Sidebar = () => {
  return (
    <div style={{width:'200px',height:'100vh',backgroundColor:'black',paddingTop:'10px'}}>

        <div style={
            {
                textAlign:'center'
            }
        }>
            <Link to={'addbook'}> <h2 style={{color:'red',cursor:'pointer'}}>add Book</h2></Link>
        </div>

         <div style={
            {
                textAlign:'center',
                marginTop:'20px'
            }
        }>
            <Link to={'listbook'}> <h2 style={{color:'red',cursor:'pointer'}}>All books</h2></Link>
        </div>
    </div>
  )
}

export default Sidebar