
let str="hello world hello"

let ch="l";

let count=0;

for(let i=0;i<str.length;i++)
{
    if(ch == str.charAt(i))
    {
        count++;
    }
}

console.log(`${ch} i occurances in string is : ${count}`)