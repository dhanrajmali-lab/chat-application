let num1=188;
let num2=18;
let num3=8;

let l1=num1%10;
let l2=num2%10;
let l3=num3%10;

if(l1==l2 && l1==l3)
{
    console.log("all last digit are same :"+l1+" "+l2+" "+l3)
}
else{
    console.log("not same :"+l1+" "+l2+" "+l3)
}