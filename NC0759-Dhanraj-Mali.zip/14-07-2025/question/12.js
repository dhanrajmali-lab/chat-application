let num1=12;
let num2=420;
let num3=490;

if(num1>num2 && num1>num2)
{
    console.log(`num1 is larger: ${num1}`);
}
else if(num2>num1 && num2>num3)
{
    console.log(`num2 is larger: ${num2}`)
}
else{
    console.log("num3 is larger:"+num3);
}