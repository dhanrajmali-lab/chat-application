let num1=60;
let num2=72;

for (let i = 1; i <= num1 && i <= num2; i++) {
//   LCM(a, b) = (a * b) / GCD(a, b)
    if( num1 % i == 0 && num2 % i == 0) {
        hcf = i;
    }
}

console.log((num1*num2)/hcf);