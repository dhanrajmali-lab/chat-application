let num=12;

console.log(Math.sqrt(num))