let str1="hello world ";


const count = str1.match(/[aeiou]/gi).length;


console.log(count)