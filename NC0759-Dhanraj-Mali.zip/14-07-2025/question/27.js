
console.log("guess the number 1-10");

let num=Math.floor(Math.random()*(10-1));

let e=4;


if(e==num)
{
    console.log("guess number is correct")
}
else{
    console.log("guess is wrong:"+num)
}