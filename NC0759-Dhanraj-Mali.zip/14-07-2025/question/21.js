
let sum=0;
let limit=5;
for(let i=1;i<=limit;i++)
{
    sum+=i;
}

console.log(sum);