
function isprime(num)
{
    if(num<=1)
    {
        return "is not prime"
    }

    for(let i=2;i<num;i++)
    {
        if(num%i==0)
        {
        return "is not prime"
        }
    }

    return "is prime"
}

console.log(isprime(10));