let num1=5;
let num2=3;



//using temp varable

let temp=num1;
    num1=num2;
    num2=temp;
    console.log(`num1:${num1} num2:${num2}`);


//without temp variable

    num1=num1+num2;
    num2=num1-num2;
    num1=num1-num2;
    console.log(`num1:${num1} num2:${num2}`);
