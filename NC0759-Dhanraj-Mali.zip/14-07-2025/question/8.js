
let cel=45

const fahrenheit = (cel * 1.8) + 32

console.log(`celcius:${cel} , fehrenheit :${fahrenheit}`);