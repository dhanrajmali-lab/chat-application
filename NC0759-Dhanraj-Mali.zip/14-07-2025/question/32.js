let val="hello";

console.log(val.charCodeAt(0))