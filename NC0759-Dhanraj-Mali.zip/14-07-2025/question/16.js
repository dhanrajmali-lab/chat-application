let num=9;


for(let i=1;i<=10;i++)
{
    console.log(`${num}x${i}=${num*i} `);
}