
function isprime(num)
{
    if(num<=1)
    {
        return 0;
    }
    
    for(let i=2;i<num;i++)
    {
        if(num%i==0)
        {
           return 0;
        }
    }

    return num;
}

let No=30;
for(let i=1;i<No;i++)
{
    let ans=isprime(i);
    if(ans==0)
    {
        console.log("is not prime number : "+i)
    }
    else{
    console.log("is prime numebr :"+i);
    }
}