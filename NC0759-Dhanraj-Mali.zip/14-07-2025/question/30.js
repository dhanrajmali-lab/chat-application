function isfact(num)
{
    if(num==0)
    {
        return 1;
    }

    return num*isfact(num-1);
}


console.log(isfact(5))