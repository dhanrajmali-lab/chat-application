// decimal to binary

let num=9;
let str=" ";
while(num>0)
{
    let rem=num%2;
     str=str+rem.toString()
    num=parseInt(num/2);
}

console.log( str)
