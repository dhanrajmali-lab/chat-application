
let num=4;

    if(num%2==0)
    {
        console.log("number is even");
    }
    else{
        console.log("number even")
    }