let num1=60;
let num2=72;

// looping from 1 to number1 and number2
for (let i = 1; i <= num1 && i <= num2; i++) {

    // check if is factor of both integers
    if( num1 % i == 0 && num2 % i == 0) {
        hcf = i;
    }
}

console.log(hcf);