
let op="*";
let num1=5;
let num2=5;


switch(op)
{
    case "+":
        console.log(num1+num2);
            break;
    
    case "-":
        console.log(num1-num2);
            break;

    case "*":
        console.log(num1*num2);
            break;   

    case "/":
        console.log(num1/num2);
            break;
            
     default:
        console.log("select valid operation symbol")       
}