let str1="naman";

let rev="";
for(let i=0;i<str1.length;i++)
{
    let ch=str1.charAt(i);
     rev=ch+rev;
}

if(str1==rev)
{
    console.log("this is palindrome :"+rev)
}
else{
    console.log("this is not palindrome :"+str1)
}