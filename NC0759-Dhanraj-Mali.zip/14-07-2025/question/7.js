let km=400;
let factor= 0.621371;

console.log("km to miles: "+km*factor);