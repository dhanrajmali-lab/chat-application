let num=5;


if(num>0)
{
    console.log("number is positive");
}
else if(num<0)
{
    console.log("number is negative");
}
else{
    console.log("number is zero")
}