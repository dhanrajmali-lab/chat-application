function isarmstrong(num)
{
    let sum=0;
    let no=num;
    if(num<10)
    {
        return true;
    }
while(num > 0)
{
    let rem=num%10;
    sum+=rem*rem*rem;
    num=parseInt(num/10);
}

if(no==sum)
{
    return true;
}
else{
    return false;
}
}



let limit=153;

for(let i=1;i<=limit;i++)
{

        if(isarmstrong(i))
        {
            console.log("armstrong number"+i);
        }      
}
