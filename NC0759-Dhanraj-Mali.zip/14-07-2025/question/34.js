let str="hello i am ghost";

const arr=str.split(' ');

arr.sort();

for(let x of arr)
{
    console.log(x);
}