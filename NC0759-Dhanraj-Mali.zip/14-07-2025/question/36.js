let str="helloworld";

let rev="";

for(let x=str.length;x>=0;x--)
{
    rev=rev+str.charAt(x);
}

console.log(rev);