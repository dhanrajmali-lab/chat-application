
let baseValue=4;
let heightValue=6;



const areaValue = (baseValue * heightValue) / 2;

console.log(areaValue);