let num=153;

let no=num;
let sum=0;
while(num > 0)
{
    let rem=num%10;
    sum+=rem*rem*rem;
    num=parseInt(num/10);
}
if(sum==no)
{
    console.log("armstrong number :"+sum);
}
else{
    console.log("not armstrong number :"+sum);
}