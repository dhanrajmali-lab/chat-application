function isfibbo(num)
{
if(num<2)
{
    return num;
}

return isfibbo(num-1)+isfibbo(num-2)
}

let limit=10;

for(let i=0;i<=limit;i++)
{
    console.log(isfibbo(i))
}