let num1=20;
let num2=40;

let sum=num1+num2;

console.log(sum)