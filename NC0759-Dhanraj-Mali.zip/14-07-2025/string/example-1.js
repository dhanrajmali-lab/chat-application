
let str="hello world";
let emoji="😊";

console.log("Strnig length is :"+str.length);

console.log(str.charAt(0));

//char code return (utf-16) limit is 0 to 65535
console.log(str.charCodeAt(0));
console.log(str.charCodeAt(12));//outof range is NAN
console.log(emoji.charCodeAt(0));// if emoji print print (55357)

//if i access any emoji char code(>35535) so charcode return broken symbol code but codepoint return code
//code point is return (unicode) 0 to 65535 and >65535 (like we need emoji code)
console.log(str.codePointAt(0));
console.log(str.codePointAt(12)); //out of range is undefine
console.log(emoji.codePointAt(0))


console.log("-------------------------------------------------");
console.log("concat methods");
console.log("-------------------------------------------------");


let str1="Hello";
let str2="world";

console.log(str1.concat("-",str2))


console.log("-------------------------------------------------");
console.log("at() methods");
console.log("-------------------------------------------------");


