//spread operator

// const obj1={a:1,b:2};
// const obj2={c:3,d:4};

// const combine={...obj1,...obj2};


// console.log(combine);


// expand using spread operator

// let a = [10, 20];
// let b = [...a, 30, 40];

// console.log(b);



// function add(x, y, z) {
//   return x + y + z;
// }

// let a = [10, 20, 30];
// console.log(add(...a));



const usr1 = {
    name: 'Jen',
    age: 22,
};

const usr2 = {
    name: "Andrew",
    location: "Philadelphia"
};

const mergedUsers = { ...usr1, ...usr2 };
console.log(mergedUsers);