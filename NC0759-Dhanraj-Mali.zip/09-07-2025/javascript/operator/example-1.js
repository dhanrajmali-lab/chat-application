// // Rest Parameter


// const[a,...arg]=[1,2,3,4,5,6,7,8,9];


// console.log(a);
// console.log(arg)



// const[a,...[x,y]]=[1,2,3,4];


// console.log(a);
// console.log(x)
// console.log(y)




// function myFunc(...args) {
//     console.log(args);
// }
// myFunc(1, 2, 3, 4, 5);


// function print(a,...arg)
// {
//     console.log("a peramenter:"+a);
//     console.log("rest all peramenter:"+arg);
// }

// print(1,2,3,4,5,6,8,9);





// function myFun(a, b, ...manyMoreArgs) {
//   console.log("a", a);
//   console.log("b", b);
//   console.log("manyMoreArgs", manyMoreArgs);
// }

// myFun("one", "two", "three", "four", "five", "six");



// function myFun(a, b, ...[c,d]) {
//   console.log("a", a);
//   console.log("b", b);
//   console.log("c", c);
//   console.log("c", d);
  
// }

// myFun("one", "two", "three", "four");