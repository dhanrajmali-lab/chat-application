
let name="raj";
console.log(typeof name);
console.log(typeof(name));


let a="123456";
console.log(typeof a);
console.log(typeof Number(a));




let b="123abcd";
console.log(b)
 b=Number(b);
 console.log(b);//print NaN (not a number) 
 console.log(typeof b)// type should be a number but value is NaN


 //String ot float
 
 console.log( parseFloat("12.22"));//convert string to float

 console.log(parseInt("12.2"));//convert stirng to integer
 