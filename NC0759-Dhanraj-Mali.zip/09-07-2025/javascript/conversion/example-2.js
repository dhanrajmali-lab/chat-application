let num=12345;

console.log(typeof num);
console.log(typeof num.toString())


console.log(typeof String(123));        // "123"
console.log(typeof String(true));       // "true"
console.log(typeof String(null));       // "null"
console.log(typeof String(undefined));  // "undefined"
console.log(typeof String([1, 2, 3]));  // "1,2,3" (calls Array's toString())

const nu = 123;
console.log(nu.toString());       // "123"

const bool = true;
console.log(bool.toString());      // "true"

const arr = [1, 2, 3];
console.log(arr.toString());       // "1,2,3"

const obj = {};
console.log(obj.toString());       // "[object Object]"

// This will throw an error:
// console.log(null.toString());
// console.log(undefined.toString());



let res = Boolean("");  
let res2 = Boolean("Hello");  
console.log(res)
console.log(res2)