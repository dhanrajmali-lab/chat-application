let age=20;

if (age > 18) {
  
    console.log("you are eligible for voting");
} else {
    console.log("your are not eligible for voting")
  
}



let marks=5;

if(marks>60)
{
    console.log("First division");
}
else if(marks>50)
{
    console.log("second division");
}
else if(marks>40)
{
    console.log("Third division");
}
else{
    console.log("Better luck of next time");
}




let day;
switch(new Date().getDate())
{
    case 0:
    day = "Sunday";
    break;
  case 1:
    day = "Monday";
    break;
  case 2:
     day = "Tuesday";
    break;
  case 3:
    day = "Wednesday";
    break;
  case 4:
    day = "Thursday";
    break;
  case 5:
    day = "Friday";
    break;
  case 6:
    day = "Saturday";
}
console.log(day);