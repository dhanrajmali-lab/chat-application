// const cars = ["BMW", "Volvo", "Saab", "Ford", "Fiat", "Audi"];

// let text = "";
// for (let i = 0; i < cars.length; i++) {
  
//     console.log(cars[i])
// }




// for(let i=1;i<=10;i++)
// {
//     console.log(i);
// }



// const person = {fname:"John", lname:"Doe", age:25}; 

// let txt = "";
// for (let x in person) {
  
//     console.log(x+":"+person[x])
// }




//fo of loop 
// const car = ["BMW", "Volvo", "Mini"];

// for (let x of car) {
//     console.log(x)
// }




// froeach loop
// const numbers = [45, 4, 9, 16, 25];

// numbers.forEach((val,i,numbers)=>{

//     console.log(i);
//     console.log(val);
//     console.log(numbers);
// })





//while loop()

// let i=1;
// while(i<=10)
// {
//     console.log(i);
//     i++;
// }




// let x=0;
// do{
//     console.log(x);
//     x++

// } while(x<10);