import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router ,Routes,Route, Link} from "react-router-dom"
import Login from './components/Login';
import Singup from './components/Singup';
import Cart from './components/cart/Cart';
import ForgotPassword from './components/ForgotPassword';
import AdminDashboard from './pages/AdminDashboard';
import User from './pages/User'
import { ToastContainer } from 'react-toastify';
import Vendor from './pages/Vendor';
import Otp from './components/Otp';
import Listproduct from './admin/Listproduct/Listproduct';
import Listproducts from './vendor/Listproduct/Listproduct';

import Addproduct from './admin/addproduct/Addproduct';
import Userlist from './admin/userList/Userlist';
import VendorList from './admin/vendorlist/VendorList';
import OrderList from './vendor/orderlist/Orderlist';
import EditUser from './admin/edituser/EditUser';
import Editproduct from './admin/editproduct/Editproduct';
function App() {
  return (

      <Router>
       

     <ToastContainer />
        <Routes>
          <Route path="/" element={<Login/>}></Route>
          <Route path="/singup" element={<Singup/>}></Route>
          <Route path="/cart" element={<Cart/>}></Route>
          <Route path="/forgot" element={<ForgotPassword/>}></Route>
          <Route path='/adminDashboard' element={<AdminDashboard />}>
                 <Route path='listprodut' element={<Listproduct/>} >
                     <Route path='editproduct/:id'  element={<Editproduct/>}></Route>
                 </Route>
                 <Route path='addproduct' element={<Addproduct/>} />
                 <Route path='userList' element={<Userlist/>}>

                         <Route path='edituser/:id' element={<EditUser/>} />
                 </Route>
                 <Route path='vendorList' element={<VendorList/>}>
                         <Route path='edituser/:id' element={<EditUser/>} />

                 </Route>
                     
          </Route>
          <Route path='/user' element={<User />}></Route>
          <Route path='/vendor' element={<Vendor />}>
            <Route path='listprodut' element={<Listproducts/>} >
            
                 <Route path='editproduct/:id'  element={<Editproduct/>}></Route>
            </Route>
            <Route path='addproduct' element={<Addproduct/>} />
            <Route path='orderlist' element={<OrderList/>} />


          </Route>
          <Route path='/otp' element={<Otp />}></Route>
        
        </Routes>

    </Router>

  );
}

export default App;
