import React from 'react'
import './Navbar.css'
import { Link } from 'react-router-dom'
const Navbar = () => {
  return (
    <div className='navbar'>
       <div className="logo">

 <a href=""><h2>WEAR <span style={{color:'crimson'}}>IT</span></h2></a>
</div>
    </div>
  )
}

export default Navbar