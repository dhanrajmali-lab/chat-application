import { Link, Outlet } from "react-router-dom"
const Vendor =()=>{
    return(
        <>

        <div style={{display:'flex'}}>
           <div className='sidebar'>
      < Link to={'addproduct'} style={{textDecoration:"none"}}>
      <div className="sidebar-item">
        <img src=""  alt=''/>
        <p>Add Product</p>
      </div>
      </Link>

      < Link to='listprodut' style={{textDecoration:"none"}}>
      <div className="sidebar-item">
        <img src=""  alt=''/>
        <p>Product List</p>
      </div>
      </Link>


       < Link to='orderlist' style={{textDecoration:"none"}}>
      <div className="sidebar-item">
        <img src=""  alt=''/>
        <p>Order List</p>
      </div>
      </Link>


    </div>
      <Outlet/>

        </div>
     
        </>
    )
}


export default Vendor