
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import Product from "../components/product/Product";

const User =()=>{

    const [data,setData] = useState([])

    useEffect(()=>{
            axios.get('http://localhost:5000/product/get')
            .then((res)=>{

                console.log(res.data.data)
                setData(res.data.data)
            })
            .catch((error)=>{
                console.log("er",error)
            })
    },[])

    return(
        <>
         <div className="h-list">
    
          <li><Link to="/"> <i class="ri-user-line"></i></Link></li>
          <li><Link to="/cart"> <i class="ri-shopping-cart-line"></i></Link></li>
        </div>
        
        <>
         <div style={{display:'flex', flexWrap:'wrap', gap:'5px'}}>
              {data.map((ele)=>{
               return <Product data={ele}/>
         })}
         </div>
       
         
            </>
        </>
    )
}


export default User;