
import "./Admin.css"
import { Outlet, Route,Routes } from 'react-router-dom'
import  Sidebar from "../admin/Sidebar/Sidebar"
import Addproduct from "../admin/addproduct/Addproduct"
import Listproduct from "../admin/Listproduct/Listproduct"
import { Link } from "react-router-dom"
const AdminDashboard =()=>{

return(
   <div className='admin' style={{display:'flex'}}>
      <Sidebar/>
         <Outlet/>
       </div>
)
}

export default AdminDashboard