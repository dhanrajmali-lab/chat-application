import { Link } from "react-router-dom"
import axios from "axios";
import "./Product.css";
const Product =(props)=>{

    const addToCart=(id)=>{

        axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('token')}`;

            axios.post(`http://localhost:5000/cart/addtocart/${id}`)
            .then((res)=>{
                console.log(res)
            })
            .catch((er)=>{
                console.log(er)
            })
    }
    return(
        <div className="product-card">
		<div className="product-tumb">
			<img src={`http://localhost:5000/uploads/`+props.data.image} alt="" />
		</div>
		<div className="product-details">
			<span className="product-catagory">{props.data.category}</span>
			<h4><Link to="#">{props.data.name}</Link></h4>
			<p>{props.data.description}</p>
			<div className="product-bottom-details">
				<div className="product-price"><small>{props.data.price}</small>{props.data.price}</div>
				<div className="product-links">
					<i className="ri-shopping-cart-line" onClick={()=>addToCart(props.data.id)} ></i>
				</div>
			</div>
		</div>
	</div>
    )
}
export default Product