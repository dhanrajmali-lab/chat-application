import { createContext } from "react";

const context =createContext()
const ContextApi =()=>{

    return(
        <context.Provider>
            
        </context.Provider>
    )

}


export default ContextApi;