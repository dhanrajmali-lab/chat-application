import { product, review } from "../model/index.js";

const addReview = async (req,res) => {
    
    try {
        
        const {star,text} = req.body;

        const givenby=res.user.data.id;

        const productid=req.params.id;


        await review.create({star,text,givenBy:givenby,productId:productid})

        res.status(200).json({msg:"review is added"})

    } catch (error) {
        res.status(500).json({error})
    }
}


const deleteReview = async (req,res) => {
    
    try {
        const id=req.params.id;

        await review.destroy({where:{id:id}})

        res.status(200).json({msg:"review is deleted"})

    } catch (error) {
        res.status(500).json({error})
    }
}


const getReviewByProductId = async (req,res) => {
    
    try {

        const id = req.params.id;
        const data= await review.findAll({where:{id:id},include:product})

        res.status(200).json({data})
        
    } catch (error) {
     
        res.status(500).json({error})
        
    }
}


export default{addReview,deleteReview,getReviewByProductId}