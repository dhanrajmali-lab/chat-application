import { DataTypes } from 'sequelize'
import  sequelize from '../config/db.js'
const order = sequelize.define('order',
    {
        orderitem:{
            type:DataTypes.STRING,
            allowNull:false,
        },
        product_id:{
            type:DataTypes.STRING,
            allowNull:false,
        },
        orderBy:{
            type:DataTypes.STRING,
            allowNull:false
        },
         orderstatus:{
            type:DataTypes.ENUM,
            values:['shipped','pending','delivered']
        },
        paymentinfo:{
            type:DataTypes.STRING,
            allowNull:false
        },
        shipingAddress:{
            type:DataTypes.STRING,
            allowNull:false
        }
    }
)

export default order