import { DataTypes } from 'sequelize'
import  sequelize from '../config/db.js'
const shiping = sequelize.define('shiping',
    {
        shipingAddress:{
            type:DataTypes.STRING,
            allowNull:false,
        },
        shipingMethod:{
            type:DataTypes.STRING,
            allowNull:false,
        },
        trackingNumber:{
            type:DataTypes.STRING,
            allowNull:false
        },
        shipingStatus:{
            type:DataTypes.STRING,
            allowNull:false
        }
    }
)


export default shiping