import './App.css';
import Login from './components/Login';
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Singup from './components/Singup';
 import { ToastContainer} from 'react-toastify';
import Index from './pages/index'
import Quizecreate from './components/Quizecreate';
import Addtitel from './components/Addtitel';
import Quizedisplay from './components/Quizedisplay';
import Quize from './components/Quize';


function App() {
  return (
    <>
    <Router>
    <ToastContainer/>
      <Routes>
      <Route path='/' element={<Login />}/>
      <Route path='/singup' element={<Singup />}/>
      <Route path='/index' element={<Index />}/>
      <Route path='/createquize/:id' element={<Quizecreate />}/>
      <Route path='/addtitel' element={<Addtitel />}/>
      <Route path='/quizelist' element={<Quizedisplay />}/>
      <Route path='/quize/:id' element={<Quize />}/>


      </Routes>
    </Router>
</>
);
}

export default App;
