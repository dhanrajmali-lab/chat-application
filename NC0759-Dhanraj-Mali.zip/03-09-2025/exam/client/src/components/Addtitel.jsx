import axios from "axios"
import { useState } from "react"
import { useNavigate } from "react-router-dom"


const Addtitel =()=>{
    const navigate= useNavigate()
    const [titel,setTitel] =useState('')

    const handlesubmit=(e)=>
    {
        e.preventDefault()
         axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('token')}`;
        axios.post('http://localhost:5000/quize/creatTitel',{titelName:titel})
        .then((res)=>{
            console.log(res.data.id)

            navigate(`/createquize/${res.data.id}`)
        })
        .catch((er)=>{
            console.log(er)
        })
    }
    return(
        
            <div className="main">
        <div className="box">
          <form onSubmit={handlesubmit}>
            <div className="heading">
              <h1>Enter quize Titel</h1>
            </div>
            <div className="group">
              <label for="titel">Titel :</label>
              <input
                type="text"
                value={titel}
                onChange={(e)=>{setTitel(e.target.value)}}
                required
              />
            </div>

        
            <div  style={{textAlign:'center'}}>
            <button type="submit" className="submit">ADD</button>

            </div>


            
          </form>
        </div>
      </div>
    )
}


export default Addtitel