import axios from "axios"
import { useEffect, useState } from "react"
import { Link, useNavigate } from "react-router-dom"


const Quizedisplay =()=>{

    const navigate=useNavigate()

    const [data,setData]= useState([])

        useEffect(()=>{
            axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('token')}`;
            axios.get('http://localhost:5000/quize/alltitel')
            .then((res)=>{
                console.log(res.data)
                setData(res.data)
            })
            .catch((er)=>{
                console.log(er)
            })
        },[])

       
        
        const handlebtn =(id)=>{
            navigate(`/quize/${id}`)
        }
    return(
        <>

        <div style={{display:'flex',justifyContent:'center',alignItems:'center', height:'50vh'}}>

       <div>
        <div className="heading">
              <h1>All Quize Topic</h1>


            </div>
            
            
            
             <div
        style={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: "20px",
        }}
      >
          
        {data.map((item,i)=>{

            return  <div
          style={{ width: "250px", height: "200px", border: "1px solid black" }}
        >
          <div className="heading">
            <h1>{item.titelName}</h1>
          </div>

          <div style={{ textAlign: "center" }}>
           
              <button onClick={()=>{handlebtn(item.id)}} className="submit">
                solve Quize
              </button>
       
          </div>
        </div>
        })}

             
     </div>
     </div>

      </div>
            </>
        
    )
}


export default Quizedisplay