import axios from "axios"
import { useEffect, useState } from "react"
import { useParams } from "react-router-dom"




const Quize =()=>{

    const {id}= useParams();

    const [data, setData] = useState([])
      const [value, setValue] = useState('');

    useEffect(()=>{

        axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('token')}`;
        axios.get(`http://localhost:5000/quize/allquize/${id}`)
        .then((res)=>{
            console.log(res.data)
            setData(res.data)
        })
        .catch((er)=>{
            console.log(er)
        })

    },[])

    const handleChange = (event) => {
        console.log(event)
    setValue(event.target.value);
  };
    const handlesubmit =(e)=>{
        e.preventDefault()
        console.log(e)
    }

    return(
    
            <>
                <div>
                 <form onSubmit={handlesubmit}>

                    {data.map((item)=>{
                       return <div key={item.id}>
                            <p> <span style={{fontSize:"20px",fontWeight:"bold"}}>Question:</span> {item.quetionName}</p>

                                           {Object.keys(item.options).map((key) => (
                                                <li key={key} style={{listStyle:'none'}}>
                                                <input type="radio"  name={item.id}  onChange={handleChange} value={item.options[key]}   /> 
                                                    <strong>{key}:</strong> {item.options[key]}
                                                </li>

                                                ))}

                            
                       </div> 
                    })}

                    <button className="submit" type="submit"> submit</button>

                    </form>
                </div>
                
            </>

    )
}


export default Quize