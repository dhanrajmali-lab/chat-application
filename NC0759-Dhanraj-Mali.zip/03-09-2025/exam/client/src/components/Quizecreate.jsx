import axios from 'axios'
import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
const Quizecreate =()=>{

            const{id}= useParams()
            
            const navigate=useNavigate()
        const [question ,setQuestion]=useState('');
        const [a,setOption1]=useState('')
        const [b,setOption2]=useState('')
        const [c,setOption3]=useState('')
        const [d,setOption4]=useState('')
        const [answer,setAnswer]=useState('')
        const [score,setScore]=useState(0)
    const handlesubmit=(e)=>{


        try {
        e.preventDefault()
            
        
                const options ={
                    a,
                    b,
                    c,
                    d
                }
                console.log(options)

               axios.defaults.headers.common['Authorization'] = `Bearer ${localStorage.getItem('token')}`;
             axios.post('http://localhost:5000/quize/createquize',{quetionName:question,options,answer,scoreValue:score,titelId:id}
             )
        .then((res)=>{
            
                console.log(res)

                setQuestion('');
                setOption1('')
                setOption2('')
                setOption3('')
                setOption4('')
                setAnswer('')
                setScore(0)



           
        })
        .catch((er)=>{
            console.log("error",er)
        })

        } catch (error) {
            console.log(error)
        }
    }

    return(<>

            <div className="main">
        <div className="box" style={{}}>
          <form onSubmit={handlesubmit}>
            <div className="heading">
              <h1>quize add</h1>
            </div>
            <div className="group">
              <label for="text">question :</label>
              <input
                type="text"
                value={question}
                onChange={(e)=>setQuestion(e.target.value)}
                required
              />
            </div>

            <div className="group">
              <label for="text">choice one</label>
              <input
                type="text"
                 value={a}
                onChange={(e)=>setOption1(e.target.value)}
                required
              />
            </div>
             <div className="group">
              <label for="text">choice two</label>
              <input
                type="text"
                value={b}
                onChange={(e)=>setOption2(e.target.value)}
                required
              />
            </div> <div className="group">
              <label for="text">choice three</label>
              <input
                type="text"
                value={c}
                onChange={(e)=>setOption3(e.target.value)}
                required
              />
            </div> <div className="group">
              <label for="text">choice four</label>
              <input
                type="text"
                value={d}
                onChange={(e)=>setOption4(e.target.value)}
                required
              />
            </div>
        
            <div className="group">
              <label for="text">answer</label>
              <input
                type="text"
                value={answer}
                onChange={(e)=>setAnswer(e.target.value)}
                required
              />
            </div>

            <div className="group">
              <label for="text">score value</label>
              <input
                type="text"
                value={score}
                onChange={(e)=>setScore(e.target.value)}
                required
              />
            </div>
            <div  style={{textAlign:'center'}}>
            <button type="submit" className="submit">ADD more</button>

            <button style={{marginLeft:'5px'}}  className="submit" onClick={()=>navigate('/index')}>finish</button>


            </div>


            
          </form>
        </div>
      </div>
      </>)
}


export default Quizecreate