import { Link } from "react-router-dom";

const Index = () => {
  return (
    <>
      <div
        style={{
          width: "100%",
          height: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: "20px",
        }}
      >
        <div
          style={{ width: "250px", height: "250px", border: "1px solid black" }}
        >
          <div className="heading">
            <h1>All Quize List</h1>
          </div>

          <div style={{ textAlign: "center" }}>
            <Link to={"/quizelist"}>
              {" "}
              <button type="submit" className="submit">
                check
              </button>
            </Link>
          </div>
        </div>



         <div
          style={{ width: "250px", height: "250px", border: "1px solid black" }}
        >
          <div className="heading">
            <h1>Create Quize</h1>
          </div>

          <div style={{ textAlign: "center" }}>
            <Link to={"/addtitel"}>
              
              <button type="submit" className="submit">
                check
              </button>
            </Link>
          </div>
        </div>



         <div
          style={{ width: "250px", height: "250px", border: "1px solid black" }}
        >
          <div className="heading">
            <h1>Quize Details</h1>
          </div>

          <div style={{ textAlign: "center" }}>
            <Link>
              {" "}
              <button type="submit" className="submit">
                check
              </button>
            </Link>
          </div>
        </div>

      </div>
    </>
  );
};

export default Index;
