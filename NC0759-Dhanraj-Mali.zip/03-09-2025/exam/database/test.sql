-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 03, 2025 at 02:07 PM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `quizes`
--

DROP TABLE IF EXISTS `quizes`;
CREATE TABLE IF NOT EXISTS `quizes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quetionName` varchar(255) DEFAULT '0',
  `answer` varchar(255) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `scoreValue` int DEFAULT '0',
  `options` json DEFAULT NULL,
  `titelId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `titelId` (`titelId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `quizes`
--

INSERT INTO `quizes` (`id`, `quetionName`, `answer`, `createdAt`, `updatedAt`, `scoreValue`, `options`, `titelId`) VALUES
(8, 'hello', 'a', '2025-09-03 11:53:19', '2025-09-03 11:53:19', 1, '{\"option1\": \"a\", \"option2\": \"b\", \"option3\": \"c\", \"option4\": \"d\"}', 4),
(9, 'dhfjhdjhfvjdhjk', 'a', '2025-09-03 11:57:35', '2025-09-03 11:57:35', 1, '{\"option1\": \"a\", \"option2\": \"b\", \"option3\": \"c\", \"option4\": \"d\"}', 5),
(10, 'kdjkfjdkj', 'd', '2025-09-03 11:58:13', '2025-09-03 11:58:13', 2, '{\"option1\": \"k\", \"option2\": \"k\", \"option3\": \"kj\", \"option4\": \"d\"}', 5),
(11, 'what is node js', 'single threded', '2025-09-03 13:12:29', '2025-09-03 13:12:29', 1, '{\"a\": \"single threded\", \"b\": \"multi threaded\", \"c\": \"both\", \"d\": \"other\"}', 7),
(12, 'what is javascrip js', 'single threded', '2025-09-03 13:14:03', '2025-09-03 13:14:03', 1, '{\"a\": \"single threded\", \"b\": \"multi threaded\", \"c\": \"both\", \"d\": \"other\"}', 7);

-- --------------------------------------------------------

--
-- Table structure for table `titels`
--

DROP TABLE IF EXISTS `titels`;
CREATE TABLE IF NOT EXISTS `titels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titelName` varchar(255) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `titels`
--

INSERT INTO `titels` (`id`, `titelName`, `createdAt`, `updatedAt`, `userId`) VALUES
(4, 'hello', '2025-09-03 11:35:18', '2025-09-03 11:35:18', 6),
(5, 'hello', '2025-09-03 11:57:16', '2025-09-03 11:57:16', 6),
(7, 'node js', '2025-09-03 13:11:02', '2025-09-03 13:11:02', 6);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) DEFAULT '0',
  `userEmail` varchar(255) DEFAULT '0',
  `userPassword` varchar(255) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `userEmail` (`userEmail`),
  UNIQUE KEY `userEmail_2` (`userEmail`),
  UNIQUE KEY `userEmail_3` (`userEmail`),
  UNIQUE KEY `userEmail_4` (`userEmail`),
  UNIQUE KEY `userEmail_5` (`userEmail`),
  UNIQUE KEY `userEmail_6` (`userEmail`),
  UNIQUE KEY `userEmail_7` (`userEmail`),
  UNIQUE KEY `userEmail_8` (`userEmail`),
  UNIQUE KEY `userEmail_9` (`userEmail`),
  UNIQUE KEY `userEmail_10` (`userEmail`),
  UNIQUE KEY `userEmail_11` (`userEmail`),
  UNIQUE KEY `userEmail_12` (`userEmail`),
  UNIQUE KEY `userEmail_13` (`userEmail`),
  UNIQUE KEY `userEmail_14` (`userEmail`),
  UNIQUE KEY `userEmail_15` (`userEmail`),
  UNIQUE KEY `userEmail_16` (`userEmail`),
  UNIQUE KEY `userEmail_17` (`userEmail`),
  UNIQUE KEY `userEmail_18` (`userEmail`),
  UNIQUE KEY `userEmail_19` (`userEmail`),
  UNIQUE KEY `userEmail_20` (`userEmail`),
  UNIQUE KEY `userEmail_21` (`userEmail`),
  UNIQUE KEY `userEmail_22` (`userEmail`),
  UNIQUE KEY `userEmail_23` (`userEmail`),
  UNIQUE KEY `userEmail_24` (`userEmail`),
  UNIQUE KEY `userEmail_25` (`userEmail`),
  UNIQUE KEY `userEmail_26` (`userEmail`),
  UNIQUE KEY `userEmail_27` (`userEmail`),
  UNIQUE KEY `userEmail_28` (`userEmail`),
  UNIQUE KEY `userEmail_29` (`userEmail`),
  UNIQUE KEY `userEmail_30` (`userEmail`),
  UNIQUE KEY `userEmail_31` (`userEmail`),
  UNIQUE KEY `userEmail_32` (`userEmail`),
  UNIQUE KEY `userEmail_33` (`userEmail`),
  UNIQUE KEY `userEmail_34` (`userEmail`),
  UNIQUE KEY `userEmail_35` (`userEmail`),
  UNIQUE KEY `userEmail_36` (`userEmail`),
  UNIQUE KEY `userEmail_37` (`userEmail`),
  UNIQUE KEY `userEmail_38` (`userEmail`),
  UNIQUE KEY `userEmail_39` (`userEmail`),
  UNIQUE KEY `userEmail_40` (`userEmail`),
  UNIQUE KEY `userEmail_41` (`userEmail`),
  UNIQUE KEY `userEmail_42` (`userEmail`),
  UNIQUE KEY `userEmail_43` (`userEmail`),
  UNIQUE KEY `userEmail_44` (`userEmail`),
  UNIQUE KEY `userEmail_45` (`userEmail`),
  UNIQUE KEY `userEmail_46` (`userEmail`),
  UNIQUE KEY `userEmail_47` (`userEmail`),
  UNIQUE KEY `userEmail_48` (`userEmail`),
  UNIQUE KEY `userEmail_49` (`userEmail`),
  UNIQUE KEY `userEmail_50` (`userEmail`),
  UNIQUE KEY `userEmail_51` (`userEmail`),
  UNIQUE KEY `userEmail_52` (`userEmail`),
  UNIQUE KEY `userEmail_53` (`userEmail`),
  UNIQUE KEY `userEmail_54` (`userEmail`),
  UNIQUE KEY `userEmail_55` (`userEmail`),
  UNIQUE KEY `userEmail_56` (`userEmail`),
  UNIQUE KEY `userEmail_57` (`userEmail`),
  UNIQUE KEY `userEmail_58` (`userEmail`),
  UNIQUE KEY `userEmail_59` (`userEmail`),
  UNIQUE KEY `userEmail_60` (`userEmail`),
  UNIQUE KEY `userEmail_61` (`userEmail`),
  UNIQUE KEY `userEmail_62` (`userEmail`),
  UNIQUE KEY `userEmail_63` (`userEmail`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `userName`, `userEmail`, `userPassword`, `createdAt`, `updatedAt`) VALUES
(6, 'raj', 'raj@gmail.com', '$2b$05$e4zSAEkSbuPva3z7vVRosudVui4wpsXyOYypVA2H7mCDFe5HC3LNq', '2025-09-03 07:07:59', '2025-09-03 07:07:59'),
(10, 'dhanraj', 'dhanraj@gmail.com', '$2b$05$hrT31O3Gr/uYu.pZydehnuYvojB4NZc8dtYeGHEdmJEsLEW4zlzba', '2025-09-03 09:03:19', '2025-09-03 09:03:19');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `quizes`
--
ALTER TABLE `quizes`
  ADD CONSTRAINT `quizes_ibfk_1` FOREIGN KEY (`titelId`) REFERENCES `titels` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `titels`
--
ALTER TABLE `titels`
  ADD CONSTRAINT `titels_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
