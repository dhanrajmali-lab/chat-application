import { DataTypes } from "sequelize";
import sequelize from "../config/db.js";


const quize = sequelize.define('quize',
    {
        quetionName:{
            type:DataTypes.STRING,
            defaultValue:false
        },
        options:{
             type: DataTypes.JSON,
            defaultValue:false
        },
        answer:{
            type:DataTypes.STRING,
            defaultValue:false
        },
         scoreValue:{
            type:DataTypes.INTEGER,
            defaultValue:false
        }
    }
)

export default quize