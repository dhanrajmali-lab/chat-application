import { DataTypes } from "sequelize";
import sequelize from "../config/db.js";


const titel = sequelize.define('titel',
    {
        titelName:{
            type:DataTypes.STRING,
            defaultValue:false
        }
    }
)

export default titel