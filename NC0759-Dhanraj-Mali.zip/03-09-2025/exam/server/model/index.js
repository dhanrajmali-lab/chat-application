import sequelize from "../config/db.js";
import quize from "./quizeModel.js";
import user from "./userModel.js"
import titel from "./topicModel.js";

user.hasMany(titel);
titel.belongsTo(user)


titel.hasMany(quize)
quize.belongsTo(titel)

sequelize.sync({alter:true});


export {user,quize,titel}

