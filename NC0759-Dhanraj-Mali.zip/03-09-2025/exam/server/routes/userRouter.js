import express from 'express';
import {userCreate,userLogin} from '../controller/userController.js'


const userRouter =express.Router();

userRouter.get('/',(req,res)=>{
    res.send("hello")
})
userRouter.post('/create',userCreate);
userRouter.post('/login',userLogin)

export default userRouter
