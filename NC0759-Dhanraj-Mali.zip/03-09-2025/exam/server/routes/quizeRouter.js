import express from 'express';
import {createQuize,getBytitelid} from  '../controller/quizeController.js'

import {addTitel,getAllTitel} from '../controller/titelController.js';


const quizeRouter =express.Router();


quizeRouter.post('/createquize',createQuize);

quizeRouter.post('/creatTitel',addTitel);

quizeRouter.get('/alltitel',getAllTitel);

quizeRouter.get('/allquize/:id',getBytitelid);





export default quizeRouter