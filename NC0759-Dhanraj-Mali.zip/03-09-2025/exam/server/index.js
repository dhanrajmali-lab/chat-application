import express from 'express'
import userRouter from './routes/userRouter.js';
import cors from 'cors'
import verifyToken from './middleware/jwtVerify.js';
import quizeRouter from './routes/quizeRouter.js';
const app = express();
app.use(cors())
app.use(express.json())
app.use(express.urlencoded())


app.get('/',(req,res)=>{
    res.send("working")
})

app.use('/user',userRouter)

app.use('/quize',verifyToken,quizeRouter)
app.listen(5000,()=>{
    console.log("server is runinig port 5000")
})