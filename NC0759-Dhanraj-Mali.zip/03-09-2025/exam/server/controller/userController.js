import {user} from "../model/index.js";
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
const secrectkey="123456"
const userCreate =async(req,res)=>{

    try {
        const {name,email,password} = req.body;


        const haspass= bcrypt.hashSync(password,5)


        await user.create({userName:name,userEmail:email,userPassword:haspass})

        res.status(200).json({msg:"user is created"})
        
    } catch (error) {
        res.status(500).json({error})
    }
}

const userLogin = async (req, res) => {
  try {
    console.log("hello")
    const { email, password } = req.body;
    const data = await user.findOne({ where: { userEmail: email } });

    if (data == null) {
      res.status(404).json({ msg: "user is not found" });

    }
     else if (bcrypt.compareSync(password, data.userPassword) == false) {
      res.status(201).json("password is incorrected");
    } else {

      const token = jwt.sign({ data }, secrectkey, {
        expiresIn: "1d",
      });

      res.status(200).json({ msg: "user is loging ",jwt:token });
    }
  } catch (error) {
    res.status(500).json({ error: "something wrong", msg: error });
  }
};


export {userCreate,userLogin}