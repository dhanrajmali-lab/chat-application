import {  titel } from "../model/index.js";


const addTitel =async (req,res) => {

    try {
        
        const data = req.body;

        data.userId=res.user.data.id

        const item=await titel.create(data)


        res.status(200).json({msg:"titel is add",id:item.id})
        
    } catch (error) {
        res.status(500).json({error})
    }
    
}

const getAllTitel =async (req,res) => {

    try {
        
        const item=await titel.findAll()

        res.status(200).json(item)
        
    } catch (error) {
        res.status(500).json({error})
    }
    
}

export {addTitel,getAllTitel} 