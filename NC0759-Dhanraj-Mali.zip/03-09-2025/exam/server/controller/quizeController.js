import { quize } from "../model/index.js";



const createQuize=async (req,res) => {

    try {
        
        const data = req.body;
        console.log(data)
        
        await quize.create(data)

        res.status(200).json({msg:"quize is created"})

    } catch (error) {
        res.status(500).json({error})
    }
    
}


const getBytitelid=async (req,res) => {

    try {

        const id= req.params.id;

        console.log(id)

        const data=await quize.findAll({where:{titelId :id}})

        res.status(200).json(data)

    } catch (error) {
        res.status(500).json({error})
    }
    
}

export {createQuize,getBytitelid}