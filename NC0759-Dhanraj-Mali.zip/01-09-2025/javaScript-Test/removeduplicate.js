//optimize code
let str="deloitte" // dloi

const map = new Map()

// console.log(map)

for(let x=0;x<str.length;x++)
{
    map[str[x]]=0;
}

for(let x=0;x<str.length;x++)
{
    map[str[x]]++;
}
console.log

for(let x in map)
{
    if(map[x] == 1)
    {
        console.log(x)
    }
}





//not optimize code

let a="deloitte" // dloi

let ans="";
let re="";
for(let x=0;x<a.length;x++)
{
  if( ans.includes(a[x]) == false )
  {
      ans+=a[x]
    // console.log(a[x])
  }
  else
  {
    re+=a[x]
  }
}

console.log(ans)
console.log(re)

let finalans=""
// console.log(re[x])
     for(let k=0;k<ans.length;k++)
     {
        //  console.log(ans[k])
         if(re.includes(ans[k]) == false)
         {
            //  console.log(ans[k])
            finalans+=ans[k]
         }
     }


console.log(finalans)


// const ans= new Set(a)

// console.log(ans)

