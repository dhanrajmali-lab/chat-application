//Keep only characters that appears twice
//optimize code
let str1 = "success"  //output = c

const map = new Map()

for(let x=0;x<str1.length;x++)
{
    map[str1[x]]=0;
}

for(let x=0;x<str1.length;x++)
{
    map[str1[x]]++;
}


console.log(map)
for(let k in map)
{
  if(map[k] == 2)
    {
     console.log(k)
    }
}










//Keep only characters that appears twice
let str = "success"  //output = c


let ans="";
let count = 1;
let more=""
for(let x=0;x<str.length;x++)
{
    for(let k=x+1;k<str.length;k++)
    {
        // console.log(str[x]+'-'+str[k])
        if(str[x] == str[k])
        {
            count++;
            // console.log(count)
        }
    }
     if(count == 2)
          {
            ans+=str[x]
            //  console.log("hello"+str[x])
          
         }
        if(count >2)
        {
         more+=str[x]   
        }
    count = 1;
  
}

console.log(ans)
console.log(more)


let finaans="";

for(let k=0;k<more.length;k++)
{
  
for(let i=0;i<ans.length;i++)
{
    // console.log(ans[i])
    if(more.includes(ans[i]) == false)
    {
        finaans+=ans[i]
    }
}
}

console.log(finaans)

