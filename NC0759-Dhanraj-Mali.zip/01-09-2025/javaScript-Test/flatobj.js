const input = {
  user: {
    name: "Alice",
    contact: {
      email: "alice@example.com",
      phone: {
        mobile: "1234567890",
        landline: "0112345678"
      }
    },
    preferences: {
      notifications: {
        email: true,
        sms: false
      },
      theme: "dark"
    }
  },
  meta: {
    createdAt: "2025-07-29",
    verified: true
  }
};


function flatobj(k,input)
{
  for(let key in input)
    {
         k=k+"."+key;
      
        if(typeof input[key] != 'object')
        {
            // console.log(k)
         console.log(k+":"+input[key])   
        }
        else
        {
         flatobj(k,input[key])   
        }
    } 
}

let k="input"

flatobj(k,input);

