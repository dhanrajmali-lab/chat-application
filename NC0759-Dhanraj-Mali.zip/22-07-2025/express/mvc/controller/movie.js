
var movies = [
    { id: 101, name: "Fight Club", year: 1999, rating: 8.1 },
    { id: 102, name: "Inception", year: 2010, rating: 8.7 },
    { id: 103, name: "The Dark Knight", year: 2008, rating: 9 },
    { id: 104, name: "12 Angry Men", year: 1957, rating: 8.9 }
];


async function getallmovie(req, res) {

    if (movies) {
        res.status(200).send(movies)
    }
    else {
        res.status(404).send("not found")
    }

}

async function getmoviebyid(req, res) {
    const id = req.params.id;
    const movie = movies.find((item) => item.id == id)
    if (movie) {
        res.status(200).send(movie)
    }
    else {
        res.status(404).send("movie is not found");
    }
}

async function patchmoviebyid(req, res) {
    const id = req.params.id;
    const data = req.body;

    try {
        const item = movies.find(obj => obj.id == id);

        for (let x in data) {
            item[x] = data[x]
        }
        res.status(201).send("fileds are successfully added");

    }
    catch (err) {
        res.status(204).send(err);
    }

}


async function postaddnewmovie(req, res) {

    try {
        const data = req.body;

        movies.push(data)

        res.status(201).send("movie is added")
    } catch (error) {

        res.status(404).send(error)
    }
}

async function deletebyid(req, res) {

    const idx = movies.findIndex((obj) => obj.id == req.params.id);

    try {
        movies[idx]= [];

        res.status(200).send("deleted")
    }
    catch (err) {
        res.status(404).send(err);
    }
}
async function putmovie(req,res){

     const item=req.body;
    try{
        const idx=movies.findIndex(obj=> obj.id==item.id);
        data[idx]=item;
        res.status(200).send("movie is updated")
    }
    catch(err){
        res.status(404).send(err);
    }
}


module.exports = { getmoviebyid, getallmovie, patchmoviebyid, postaddnewmovie, deletebyid,putmovie }
