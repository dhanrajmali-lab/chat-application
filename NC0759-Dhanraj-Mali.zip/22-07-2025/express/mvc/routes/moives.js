const express=require('express');
const router=express.Router();
const {getmoviebyid,getallmovie,patchmoviebyid,postaddnewmovie,deletebyid,putmovie}=require('../controller/movie')


router.get('/',getallmovie);

router.
    route('/:id')
    .get(getmoviebyid)
    .patch(patchmoviebyid)
    .delete(deletebyid)

router.post('/newmovie',postaddnewmovie)
router.put('/update',putmovie)
module.exports=router;