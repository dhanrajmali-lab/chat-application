const express = require('express')
const multer = require('multer');
const env = require('dotenv');
const app= express();
env.config();
const movie = require('./routes/moives')

app.use(express.json());


app.get('/',(req,res)=>{
    res.send("hello")
})


app.use('/movies', movie)

app.listen(process.env.PORT,()=>{
    console.log("app is runing on port number"+process.env.PORT)
})