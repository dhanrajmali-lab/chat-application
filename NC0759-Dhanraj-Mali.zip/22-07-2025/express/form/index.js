const express=require('express');
const app=express();
app.set('view engine', 'pug');
app.set('views','./views');
app.use(express.json());
app.use(express.urlencoded()); 
const dotenv=require('dotenv')
dotenv.config()

app.get('/',(req,res)=>{

        res.render('form.pug')
})

app.post('/form',(req,res)=>{

    const data=req.body;

    console.log(data)
    res.send("successfully data is recive :"+ data.say +" "+ data.to)
})



/// multiple routing in js

    app.get('/home',(req,res,next)=>{
        res.send("hello")
        next();
    },(req,res)=>{
        res.send("hello second")
    })





  const cb0 = function (req, res, next) {
 console.log('CB0')
  next()
}

const cb1 = function (req, res, next) {
  console.log('CB1')
  next()
}

app.get('/example/d', [cb0, cb1], (req, res, next) => {
  console.log('the response will be sent by the next function ...')
  next()
}, (req, res) => {
  res.send('Hello from D!')
})
app.listen(process.env.PORT);



