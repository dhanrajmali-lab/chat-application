const express = require('express')
const app=express();
const multer=require('multer');
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'pug');
app.set('views','./views');

const storage=multer.diskStorage({
     destination: (req,file,call)=>{
        call(null, 'uploads/');
     },
     filename:(req,file,call)=>{
        call(null,Date.now() + '-'+ file.originalname);
     },
}
);

const upload=multer({storage:storage});


app.get('/',(req,res)=>{
    res.render('index.pug')
})


app.post('/upload',upload.single('file'),(req,res)=>{
    res.send("file is uploded");
})

app.listen(3000,()=>{
    console.log("app is listen on port number"+3000);
})