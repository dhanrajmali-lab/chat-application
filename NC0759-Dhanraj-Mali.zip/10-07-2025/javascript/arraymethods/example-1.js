// const num=[1,2,3,4,5,6,7,8]


// num.forEach((val,i,arr)=>{
//     console.log(`index ${i}:element :${val} :${arr}`)

// })


// const kvArray = [
//   { key: 1, value: 10 },
//   { key: 2, value: 20 },
//   { key: 3, value: 30 },
// ];

// const reformattedArray = kvArray.map(({ key, value }) => ({ [key]: value }));

// console.log(reformattedArray); 
// console.log(kvArray);




// const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// // Filter for even numbers
// const evenNumbers = numbers.filter(num => num % 2 === 0);
// console.log(evenNumbers); // Output: [2, 4, 6, 8, 10]

// // Filter for numbers greater than 5
// const greaterThanFive = numbers.filter(num => num > 5);
// console.log(greaterThanFive); // Output: [6, 7, 8, 9, 10]



// const users = [
//     { name: 'raj', age: 30, city: 'gujrat' },
//     { name: 'shubham', age: 24, city: 'rajasthan' },
//     { name: 'kumar', age: 35, city: 'gujrat' },
//     { name: 'abhi', age: 28, city: 'up' }
// ];

// // Filter for users from New York
// const newYorkUsers = users.filter(user => user.city === 'gujrat');
// console.log(newYorkUsers);

// // Filter for users older than 25
// const olderUsers = users.filter(user => user.age > 25);
// console.log(olderUsers);



// const values=[1,2,3,4,5,6,7,8,9];

// let val=values.reduce((total,val)=>{
//     console.log(`total:${total}:currentvalue:${val}`)
//     return total+val;
// },0)
// console.log(val)



// Input array contain some elements.
// let array = [-10, -0.20, 0.30, -40, -50];

// // Method (return element > 0).
// let found = array.find(function (element) {
//     return element > 0;
// });




// // Printing desired values.
// console.log(found);

//  let fruits = ["Banana", "Orange", "Apple", "Mango"];
//     fruits.sort();
//     console.log(fruits);


// const ar = [ 10, 20, 25, 100 , 40]
// console.log("assending:"+ar.sort((a,b) => a-b))
// console.log("desending:"+ar.sort((a,b) => b-a))


// let a = [
//     { name: 'Rahul', age: 30 },
//     { name: 'Jatin', age: 25 },
//     { name: 'Vikas', age: 30 },
//     { name: 'Rohit', age: 25 }
// ];

// a.sort((x, y) => x.age - y.age);

// console.log(a);



// let x=[
//     {name:"raj",age:20},
//     {name:"hello",age:22},
//     {name:"shubham",age:23},
// ]


//  let ans=x.map((val)=>{
//     if(val.name == "hello")
//     {
//         val.age=30;
//     }
//     return val;
//  })

//  console.log(ans)