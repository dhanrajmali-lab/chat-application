import blog from '../model/blogModel.js'


const blogCreate = async (req,res)=>{
    try {
        const {title,description,images} = req.body;

         const createdbyname = res.user.data.name;

         await blog.create({ title,description,images,createdby: createdbyname, updatedby: createdbyname });

        res.status(200).json({ msg: "blog is created" })
        
    } catch (error) {
        res.status(500).json({msg:error})
    }
}

const blogUpdate = async (req,res)=>{
    try {
        const {title,description,images} = req.body;

         const createdbyname = res.user.data.name;

         const data=await blog.update({ title,description,images, updatedby: createdbyname },{where:{id:req.params.id}});
         if(!data)
         {
            res.status(404).json({ msg: "not found" })
         }
         else{
            res.status(200).json({ msg: "blog is update" })

         }
        
    } catch (error) {
        res.status(500).json({msg:error})
    }
}

const blogDelete = async (req,res)=>{
    try {
         const createdbyname = res.user.data.name;

         const data=await blog.destroy({where:{id:req.params.id}});
         if(!data)
         {
            res.status(404).json({ msg: "not found" })
         }
         else{
            res.status(200).json({ msg: "blog is deleted" })

         }
        
    } catch (error) {
        res.status(500).json({msg:error})
    }
}

const  getByIdblog= async (req,res)=>{
    try {
       
         const data=await blog.findOne({where:{id:req.params.id}});
         if(!data)
         {
            res.status(404).json({ msg: "not found" })
         }
         else{
            res.status(200).json({ data })

         }
        
    } catch (error) {
        res.status(500).json({msg:error})
    }
}

const  allblogGet= async (req,res)=>{
    try {
     
         const data=await blog.findAll();
         console.log(data)
         if(!data)
         {
            res.status(404).json({ msg: "not found" })
         }
         else{
            res.status(200).json({data })

         }
        
    } catch (error) {
        res.status(500).json({msg:error})
    }
}
export {blogCreate,blogUpdate,blogDelete,allblogGet,getByIdblog};