import user from "../model/userModel.js";
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken'
const secretKey = '123456';

const userRegister = async (req, res) => {
    try {
        const { name, email, password, role } = req.body;

        if (role == "admin") {
            res.status(400).json({ msg: "admin is already exist" })
        }
        else {

            const hassPassword = bcrypt.hashSync(password, 5);

            const createdbyname = res.user.data.name + "/" + res.user.data.role;

            await user.create({ name, email, password: hassPassword, role, createdby: createdbyname, updatedby: createdbyname });

            res.status(200).json({ msg: "user is created" })
        }


    } catch (error) {

        res.status(500).json({ msg: error })
    }
}

const userLogin = async (req, res) => {
    try {
        const { email, password } = req.body;
        const data = await user.findOne({ where: { email: email } })
        console.log(data)

        if (data == null) {
            res.status(404).json({ msg: "user is not found" })
        }
        else if (bcrypt.compareSync(password, data.password) == false) {
            res.status(201).json("password is incorrected")
        }
        else {

            const token = jwt.sign({ data }, secretKey, { expiresIn: '1d' });
            res.status(200).json({ msg: "user is loging", jwt: token });
        }

    } catch (error) {
        res.status(500).json({ msg: error })
    }
}



const allUser = async (req, res) => {
    try {
        const data = await user.findAll({ where: { role: 'user' } })
        res.status(200).json({ data });

    } catch (error) {
        res.status(500).json({ msg: error })
    }
}

const getById = async (req, res) => {
    try {
        if (req.params.id == 1) {
            res.status(200).json("this is admin")
        }
        else {
            const data = await user.findAll({ where: { id: req.params.id } })
            res.status(200).json({ data });
        }


    } catch (error) {
        res.status(500).json({ msg: error })
    }
}


const updateUser = async (req, res) => {

    try {
        const body = req.body;
        if (req.params.id == 1) {
            res.status(200).json("this is admin")
        }
        else {
            // const hassPassword = bcrypt.hashSync(password, 5);

            // const createdbyname = res.user.data.name + "/" + res.user.data.role;
            const item = await user.update(body, { where: { id: req.params.id } })
            console.log(item)

            res.status(200).json({ msg: "user is updated" });

        }


    } catch (error) {
        res.status(500).json({ msg: error })
    }
}


const deleteUser = async (req, res) => {

    try {
        if (req.params.id == 1) {
            res.status(200).json("this is admin")
        }
        else {

            const item = await user.destroy({ where: { id: req.params.id } })
            console.log(item)

            res.status(200).json({ msg: "user is deleted" });

        }

    } catch (error) {
        res.status(500).json({ msg: error })
    }
}

const restoreUser = async (req, res) => {

    try {
        if (req.params.id == 1) {
            res.status(200).json("this is admin")
        }
        else {

            const item = await user.restore({ where: { id: req.params.id } })
            console.log(item)

            res.status(200).json({ msg: "user is restored" });

        }

    } catch (error) {
        res.status(500).json({ msg: error })
    }
}


const userAproval = async (req, res) => {
    try {
        const data = req.params.status;
        if (req.params.id == 1) {
            res.status(200).json("this is admin")
        }
        else if (data == "yes") {
            console.log(data)
            const item = await user.update({ isAproved: data }, { where: { id: req.params.id } })
            res.status(200).json({ msg: "user is approved" });
        }
        else if (data == "no") {

            await user.destroy({ where: { id: req.params.id }, force: true })
            res.status(200).json({ msg: "no  approved user is delete permanetaly" });

        }
        else {
            res.status(400).json({ msg: "give perameter only yes or no" });
        }

    } catch (error) {
        res.status(500).json({ msg: error })

    }
}

export { userRegister, userLogin, allUser, getById, updateUser, deleteUser, restoreUser, userAproval }