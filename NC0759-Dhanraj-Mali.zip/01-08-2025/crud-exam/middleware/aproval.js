
const isAdmin = async (req, res, next) => {

    console.log(res.user.data.role)
    if (res.user.data.role == "user") {
        res.send( {msg: "current login not a admin" })
    }
    else {
        res.user.data.role;
        next();
    }
}

export default isAdmin;