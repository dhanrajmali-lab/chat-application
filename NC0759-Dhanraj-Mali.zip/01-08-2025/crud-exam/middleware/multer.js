import multer from "multer";

    const storage=multer.diskStorage({
     destination: (req,file,call)=>{
        call(null, '../uploads/');
     },
     filename:(req,file,call)=>{
        call(null,Date.now() + '-'+ file.originalname);
     },
}
);

const upload=multer({storage:storage});

const multfile=upload.array('myFiles', 3);
export default multfile 