import express from 'express'
import userRouter from './routes/userRoutes.js';
import blogRouter from './routes/bolgRoutes.js'
import dotenv  from 'dotenv';
dotenv.config();
const app = express();

app.use(express.json())
app.use(express.urlencoded());


app.get('/',(req,res)=>{
    res.status(200).json("working")
})


app.use('/user',userRouter)
app.use('/blog',blogRouter)

app.listen(process.env.PORT,()=> {
    console.log('server is start on port no :'+process.env.PORT)
});