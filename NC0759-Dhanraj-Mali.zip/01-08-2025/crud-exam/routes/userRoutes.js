import express from 'express'
import {userRegister,userLogin,allUser,getById,updateUser,deleteUser,restoreUser,userAproval} from '../controller/userController.js'
const   userRouter =express.Router();
import verifyToken from '../middleware/jwtAuthentication.js';
import isAdmin from '../middleware/aproval.js';
userRouter.get('/login',userLogin)

userRouter.post('/register',verifyToken,userRegister)

userRouter.get('/alluser',verifyToken,allUser)
userRouter.get('/aprovel/:id/:status',verifyToken,isAdmin,userAproval)


userRouter.get('/:id',verifyToken,getById)
userRouter.get('/restore/:id',verifyToken,isAdmin,restoreUser)
userRouter.put('/:id',verifyToken,updateUser)
userRouter.delete('/:id',verifyToken,deleteUser)




export default userRouter;

