
import express from 'express'
const   blogRouter =express.Router();
import verifyToken from '../middleware/jwtAuthentication.js';
import isAdmin from '../middleware/aproval.js';
import {blogCreate,blogUpdate,blogDelete,allblogGet,getByIdblog} from '../controller/blogController.js'
import multfile from '../middleware/multer.js'


blogRouter.post('/create',verifyToken,multfile,blogCreate)

blogRouter.get('/',allblogGet)

blogRouter.
     route('/:id')
    .get(verifyToken,getByIdblog)
    .delete(verifyToken,blogDelete)
    .put(verifyToken,blogUpdate)


export default blogRouter;