import { DataTypes } from "sequelize";
import sequelize from "../config/db.js";


const blog = sequelize.define('blog',{
        title: {
            type: DataTypes.STRING,
            allowNull:false
        },
        description:{
            type: DataTypes.STRING,
            allowNull:false
        },
        images:{
        type: DataTypes.JSON,
        },
        createdby:{
            type : DataTypes.STRING,
        },
        updatedby:{
            type : DataTypes.STRING,
        },
        isAproved:{
            type : DataTypes.STRING,
            defaultValue: "NO",
        }
})


blog.sync()
.then(()=>{
    console.log("blog table is created")
})
.catch((err)=>{
    console.log(err)
})

export default blog;