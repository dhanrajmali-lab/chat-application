import { DataTypes, Sequelize } from "sequelize";
import sequelize from "../config/db.js";

const user = sequelize.define('user',
    {
        name:{
            type : DataTypes.STRING,
        },
        email:{
            type : DataTypes.STRING,
             unique: true,
        },
        password:{
            type : DataTypes.STRING,
        },
        role:{
            type : DataTypes.STRING,
             defaultValue: "user",
        },
        createdby:{
            type : DataTypes.STRING,
        },
        updatedby:{
            type : DataTypes.STRING,
        },
        isAproved:{
            type : DataTypes.STRING,
            defaultValue: "NO",
        }
    },
    {
        paranoid:true,
    }
)


user.sync()
.then(()=>{
    console.log("table is created")
})
.catch((eror)=>{
    console.log("error: "+eror)
})
export default user