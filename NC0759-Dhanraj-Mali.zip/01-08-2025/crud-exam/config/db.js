import { Sequelize } from "sequelize";

const sequelize = new Sequelize('test','root','',
    {
        host: 'localhost',
        dialect:'mysql'
    })
    try {
    sequelize.authenticate();
        console.log("database is conected !!")
    } catch (error) {
        console.log("database is not connectes "+ error);
        
    }

    export default sequelize;