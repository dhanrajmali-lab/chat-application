function valid(num)
{
    if(num%2==0)
    {
        console.log(num,"is even number");
    }
    else{
        console.log(num,"is odd number")
    }
}

valid(2);