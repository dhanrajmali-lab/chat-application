function greeting()
{
    console.log("hello ");
}
greeting();

//return type function

function add(a,b)
{
    return a+b;
}
let x=add(5,5);
console.log("sum is",x);

//perameter
function person(id,name,age,mobileno,work)
{
    this.id=id;
    this.name=name;
    this.age=age;
    this.mobileno=mobileno;
    this.work=work;

    console.log("id:",this.id);
    console.log("Name:",this.name);
    console.log("age:",this.age);
    console.log("Mobile number:",this.mobileno);
    console.log("Work:",this.work);

}

person(1,"raj",22,1234567890,"devloper");