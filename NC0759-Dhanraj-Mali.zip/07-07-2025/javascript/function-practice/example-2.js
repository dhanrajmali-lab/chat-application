function sum(a,b)
{
    return a+b;
}

function sub(a,b)
{
    return a-b;
}
function mul(a,b)
{
    return a*b;
}
function divide(a,b)
{
    return a/b;
}

 function cal(a,b,o)
{
    switch(o)
    {
        case "+":
            return sum(a,b);
           
        case "-":
            return  sub(a,b);
        case "*":
            return  mul(a,b);
        case "/":
            return divide(a,b); 
        default:
            console.log("Enter valid operator")            
    }

}

console.log("add two values :",cal(5,5,"+"));
console.log("add two values :",cal(5,5,"-"));
console.log("add two values :",cal(5,5,"*"));
console.log("add two values :",cal(5,5,"/"));
