// function outerfunction()
// {
//     let name="raj";

//     console.log(name);
//     function innerfunction()
//     {
//         console.log(name);
//     }

//     return innerfunction();
// }


// let x = outerfunction;
// x();

function outer()
{
    let name="raj";
        console.log(name);
     function in1()
     {
        console.log(name);
      
         function in2()
            {
                console.log(name);

                 function in3()
                 {
                        console.log(name); ///take outer function variable references

                 }
                 in3()
            }
            in2();
            
     }
     name="hello";
     return in1();
}

let x=outer();
