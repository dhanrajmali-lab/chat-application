
function sum(a)
{
     return function (b)
     {
        console.log(a+b);
     }
}

let x=sum(5);

x(5);