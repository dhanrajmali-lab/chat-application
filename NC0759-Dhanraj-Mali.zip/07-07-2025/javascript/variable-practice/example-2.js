let a=10;//let is block level scope variable 
let b=50;

const two=122; // we can not re asign and re-declear const variable
console.log("sum is ",a+b);
console.log("const value is :",two);

x=10; // automaty variable no need for variable type 
z=30;
console.log(x+z);