// let a=12;
// let name ="raj";
// let c= true;
// let x;
// let b=null;

// console.log(typeof(a));
// console.log(typeof(name));
// console.log(typeof(c));
// console.log(typeof(x));
// console.log(typeof(b));




// javascript is reading line left to right

// we add number + string so js is consider number as a string
console.log(2+2+"raj");

console.log("hello"+12+12+1);