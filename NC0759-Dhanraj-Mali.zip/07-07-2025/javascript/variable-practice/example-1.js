var a;//var is global scope variable
var b;

a=10;
b=30;

console.log(a+b);