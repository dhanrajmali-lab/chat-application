import { createContext } from "react";

const UserContext = createContext();

const ContextApi=({children})=>{
    const user = {
      name:"raj",
      age :22
    }
  return( 
     <UserContext.Provider  value={user}>
      {children}
    </UserContext.Provider>
  )
}


export  { ContextApi,UserContext}