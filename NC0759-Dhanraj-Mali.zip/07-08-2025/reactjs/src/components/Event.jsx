

const Event =()=>{
   const handle=(ev)=>{
        
    console.log(ev)
    }
 
    return(<>

        <button onClick={(event)=>handle(event)}>add</button>
        
    </>)
}


export default Event;