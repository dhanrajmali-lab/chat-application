import { useContext } from "react";
import {UserContext} from "../context/ContextApi";

const   Child =()=>{

const user = useContext(UserContext)

    return(
        <>
            <div>
                <h1>user name is : {user.name}</h1>
                <h2>user age is : {user.age}</h2>
            </div>
        </>
    )
}


export default Child