
import React, { useEffect, useState } from "react";
 
function Demo() {
    const [data, setData] = useState(1);
    const [count, setCount] = useState(0);

     useEffect(() => {
      console.log("default")
    });

    useEffect(() => {
      console.log("empty array")
    },[]);

     useEffect(() => {
      console.log("count value change")
    },[count]);
 
    return (
        <>
    <div>
        <button onClick={() => setCount(count+1)}>+</button>
        <h5>{count}</h5>
    </div>
    
          <div>
            {data }
        <button onClick={() =>setData(data+1)}>+</button>

         </div>
   
        
        </>
  
    );
}
 
export default Demo;