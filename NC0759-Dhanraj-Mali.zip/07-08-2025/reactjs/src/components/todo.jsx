import React, { useState } from "react";

import Button from "./Button";
const Todo = () => {
  const [todo, settodo] = useState([]);
  const [value, setinput] = useState("");

  const handleclick = () => {
    settodo([...todo, value]);
    setinput("");
  };

  const deltetodo = (idx) => {
    const newtodo = [...todo];
    newtodo.splice(idx, 1);
    settodo(newtodo);
  };

  const editodo =(idx)=>{

   const items= todo.map((item,i)=>{
        if(idx === i)
        {
            return item;
        }
    })
        setinput(items)
  }

  return (
    <>
      <div className="todo-main">
        <input
          value={value}
          type="text"
          onChange={(e) => {
            setinput(e.target.value);
          }}
          className="input-section"
        />
        <Button onClick={handleclick} msg="add" />
      </div>

          <div className="todo-list">
          {todo.map((item, index) => (
            <div className="one-list">
                  <span style={{fontSize:'30px'}} key={index}> {item} </span>
                <Button onClick={() => editodo(index)} msg="edit" />
              <Button onClick={() => deltetodo(index)} msg="delete" />
            </div>
          ))}
          </div>
      
    </>
  );
};

export default Todo;
