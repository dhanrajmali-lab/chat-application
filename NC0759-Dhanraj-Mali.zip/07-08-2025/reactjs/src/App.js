import React from "react";
import './App.css';
import {BrowserRouter as Router ,Routes,Route, Link} from "react-router-dom"
import Counter from "./components/Counter"
import Home from "./components/Home"
import Todo from "./components/todo";
import Demo from "./components/Demo";
import Child from "./components/Child"
import Event from "./components/Event";
import Form from "./components/Form";
import Fakeapi from "./components/Fakeapi";
function App() {

  return (
    <Router>
        <div className="h-list">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/counter">counter</Link></li>
          <li><Link to="/todo">todo</Link></li>
          <li><Link to="/demo">demo</Link></li>
          <li><Link to="/child">contextApi</Link></li>
          <li><Link to="/event">Event</Link></li>
          <li><Link to="/form">form</Link></li>
          <li><Link to="/api">API</Link></li>

        </div>


        <Routes>

          <Route path="/" element={<Home/>}></Route>
          <Route path="/counter" element={<Counter/>}></Route>
          <Route path="/todo" element={<Todo/>}></Route>
          <Route path="/demo" element={<Demo/>}></Route>
          <Route path="/child" element={<Child/>}></Route>
          <Route path="/event" element={<Event/>}></Route>
          <Route path="/form" element={<Form/>}></Route>
          <Route path="/form" element={<Form/>}></Route>
          <Route path="/api" element={<Fakeapi/>}></Route>


        </Routes>

    </Router>
   
  );
}

export default App;
