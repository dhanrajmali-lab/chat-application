import express from "express";
import http from "http";
import { Server } from "socket.io";
import cors from "cors";
import userRouter from "./routes/userRouter.js";
import jwt from "jsonwebtoken";
const app = express();
const secrectkey="123456"

app.use(express.urlencoded());
app.use(express.json());

const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000",
  },
  connectionStateRecovery:{}
});

app.use(
  cors({
    origin: "http://localhost:3000",
  })
);

app.get("/", (req, res) => {
  res.send("hello");
});

app.use("/user", userRouter);

var users = {};

io.on("connection", (socket) => {

  socket.on("connected", (userId) =>{
    console.log('user is connected !!!!!!!!!!',userId)
    users[userId] = socket.id;
  });
  

  console.log("new id :"+ socket.id)
  console.log("user maping : ",users)

   socket.on("private message", (data) => {
    console.log(data)
      //  users[from] = socket.id;
        const id=users[data.to]
        if (id) {
            io.to(id).to(users[data.from]).emit('private message', data);

        } else {
            console.log(`Recipient ${id} not found.`);
        }

  });


  
    socket.on("join",(roomid)=>{
      console.log("group is created",roomid  )
      socket.join(roomid)
    })

    socket.on("groupchat",(roomid,data)=>{
      console.log(data)
        io.to(roomid).emit('groupchat', data)
    })

    socket.on('logout',(id) => {
      // console.log(id,users)
      delete users[id]
    // console.log('User logout', users);
    });
   socket.on('disconnect',() => {
    console.log('User disconnected',);
    });

});


server.listen(5001, () => {
  console.log("server is runing on 5000");
});
