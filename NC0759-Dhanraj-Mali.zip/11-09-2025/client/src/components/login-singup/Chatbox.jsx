import React, { useEffect ,useState} from 'react'
import { useParams } from 'react-router-dom'
import socket from "../socket";

const Chatbox = () => {
  
  const{id}= useParams()
  const [msg, setMsg] = useState("");
  const [privatemsg,setPrivatemsg] =useState([])


  useEffect(() => {
          socket.connect()  
          socket.emit("connected",localStorage.getItem('id'));
          socket.on("private message", (data) => {
          console.log("Received private message:", data);
            setPrivatemsg((privatemsg)=>[...privatemsg ,data]);
          });
          
  }, []);

  const handliBtnprivate=()=>{
    console.log(socket)
    console.log(socket.id)
    // sockets.connect()


    let detail={}

    detail['to']= id;
    detail["content"] = msg;
    detail ["from"]=localStorage.getItem('id');
    detail ["name"]=localStorage.getItem('name');


    socket.emit('private message', detail);
    //  setDisplay((display)=>[...display, msg])

    setMsg("");    
  }


  return (
    <div style={{width:'100%',height:'100vh'}}>
        <div className="display-main">
        <div id="msgdisplay">
          
        {privatemsg.map((item)=>{
          
          return  <div style={{ justifyContent: item.name==localStorage.getItem('name')?'end':'start',Width:'100%',display:'flex'}}>
            {id==item.to && localStorage.getItem('id')==item.from  || id==item.from && localStorage.getItem('id')!= item.from  ?(

               <p style={{borderRadius:'5px', width:'350px', border:'1px solid grey'}}>{item.content} 
               <div style={{fontSize:'15px',color:'red',textAlign:'end',paddingRight:'5px'}}>{item.name}</div></p>
            ) :
            (<p></p>)}
             
          
               </div>
        })}
        </div>
      </div>

      <div id="main" >
        <input
          type="text"
          id="textValue"
          value={msg}
          onChange={(e) => {
            setMsg(e.target.value);
          }}
        />
        <button onClick={handliBtnprivate} style={{background:'black',borderRadius:'5px',color:'white'}}>send msg</button>

      </div>
    </div>
  )
}

export default Chatbox