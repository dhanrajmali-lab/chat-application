import React, { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom';
import socket from './socket';
const Groupchat = () => {

    const location = useLocation();
  const data= location.state || {};

  const [msg,setMsg]= useState('')
   const [display, setDisplay] = useState([]);

   const [senderName,setSenderName]= useState('')


  console.log(data)

  useEffect(()=>{
    socket.connect()
    console.log(data.roomid)
    socket.emit("join",(data.roomid))

    socket.on("groupchat" ,(msg)=>{
    console.log("rec",msg)
    setDisplay((display)=>[...display, msg])
  })
  },[])


  const sendChat=()=>{

    let messages={}

    messages['name']=localStorage.getItem('name');
    messages['msg']=msg;


    socket.emit("groupchat",data.roomid,messages)
    setMsg('')
        }
 return (
    <div style={{width:'100%',height:'100vh'}}>
        <span><strong>group members :</strong> {data.roomMember.join("  ")}</span>
        <div className="display-main">
        <div id="msgdisplay">

          {display.map((i)=>{
          return  <div style={{display:'flex',justifyContent: i.name ===localStorage.getItem('name')?'end':'start'}}><p style={{borderRadius:'5px', width:'350px', border:'1px solid grey'}}> {i.msg}  <div style={{fontSize:'15px',color:'red',textAlign:'end',paddingRight:'5px'}}>{i.name}</div></p> </div>

          })}
       
        </div>
      </div>

      <div id="main" >
        <input
          type="text"
          id="textValue"
          value={msg}
          onChange={(e) => {
            setMsg(e.target.value);
          }}
        />
        <button  style={{background:'black',borderRadius:'5px',color:'white'}} onClick={()=>sendChat()}>Send</button>

      </div>
    </div>
  )
}

export default Groupchat