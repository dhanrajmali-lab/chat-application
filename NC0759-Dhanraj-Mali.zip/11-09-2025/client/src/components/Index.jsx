import React from 'react'
import Sidebar from './Sidebar'
import { Outlet } from 'react-router-dom'

const Index = () => {
  return (
   <>
   <div style={{display:'flex',gap:'5px'}}>
      <Sidebar/>
        <Outlet/>
   </div>
   </>
  )
}

export default Index