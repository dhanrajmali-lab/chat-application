const express=require('express');
const app=express();
const things=require('./think.js')
const user=require('./user.js')




app.use(express.json());
const PORT=3000;

app.get('/',((req,res)=>{

    res.send("<h1>Hello </h1> ")
}))


app.use(function(req, res, next){

   console.log("A new request received at " +  new Date());

   next();
});

app.use('/things',things)
app.use('/user',user)



app.use(function(req, res, next) {
      res.status(404).send("Sorry, that route doesn't exist.");
    });

app.listen(PORT,()=>{
    console.log("app is runing on server number"+PORT)
})