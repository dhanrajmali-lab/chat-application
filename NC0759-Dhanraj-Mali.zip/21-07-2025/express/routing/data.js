let users = [
  {
  id: 1,
  username: "john_doe",
  email: "john@example.com",
  isActive: true
},
{
  id: 2,
  username: "jane_smith",
  email: "jane@example.com",
  isActive: false
},
  {
    id: 3,
    username: "peter_jones",
    email: "peter@example.com",
    isActive: true
  },
  {
    id: 4,
    username: "mary_brown",
    email: "mary@example.com",
    isActive: true
  }
];

module.exports = users;