const express= require('express');
const router=express.Router();


router.get('/',(req,res)=>{
    res.send("this is router is things/")
})

router.get('/name',(req,res)=>{
    res.send("this is router is /things/name");
})


module.exports=router;