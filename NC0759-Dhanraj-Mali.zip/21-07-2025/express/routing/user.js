const express = require('express')
const router=express.Router();
const data=require('./data.js');

router.get('/',(req,res)=>{

    res.send(data);

})
router.get('/options',(req,res)=>{

    res.send(`
        1. get all user user/   =>method GET <br>
        2. get one user router=> user/id =>method GET<br>
        3. add user  router=> user/newuser  =>method POST<br>
        4. update user router=> user/update  =>method PUT<br>
        5.delete user  router=> user/delete/id  =>method DELETE<br>
        `);

})

router.get('/:id',(req,res)=>{
    id = req.params.id
    const user=data.find((item)=> item.id==id)
     if(user)
     {
         res.send(user)
     }
     else{
        res.send("user  is not found");
     }
   
})


router.post('/newuser',(req,res)=>{
    const user=req.body;
    
    if(data.push(user))
    {
        res.send("user is added")
    }
    else{
        res.send("user is not added")
    }

})

router.put('/update',(req,res)=>{

    const user=req.body;

    try{
        const idx=data.findIndex(obj=> obj.id==user.id);
        data[idx]=user;
        res.send("user is updated")
    }
    catch(err){
        res.send("error"+err);
    }

})

router.delete('/delete/:id',(req,res)=>{

   const idx= data.findIndex((obj)=>obj.id==req.params.id);

   try{
     delete data[idx];

     res.send("user is succesfully deleted");
   }
   catch(err)
   {
    res.send("something is wrong user is not delted");
   }


})


module.exports=router;
