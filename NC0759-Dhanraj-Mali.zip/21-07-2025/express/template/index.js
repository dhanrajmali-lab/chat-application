const express= require('express');
const { render } = require('pug');

const app=express();
app.set('view engine', 'pug');
app.set('views','./views');


app.get('/header',(req,res)=>{
    res.render('header.pug');
});

app.get('/',(req,res)=>{
    res.render('index.pug',{
        name:"first example in pug",
        url:"https:youtube.com"
    });
});

app.get('/login',(req,res)=>{
res.render('dynamic.pug',{
        user:{name:"dhanraj",lname:"Mali"}
    })
})


app.get('/footer',(req,res)=>{
    res.render('footer.pug');
});





app.listen(3000);