import React from "react";


const Display =(props)=>{
    return(
        <h2>
        values : {props.data}
          </h2>
    )
}


export default Display;