import React, { useState } from "react";

import Button from "./Button";
const Todo =()=>{

    const [todo,settodo]=useState([])
    const [value,setinput]=useState('')


    const handleclick=()=>{

            settodo([...todo,value]);
            setinput('');
    }
    const deltetodo =(idx)=>{
        const newtodo=[...todo]
        newtodo.splice(idx,1)
        settodo(newtodo)
    }

    return(<>

        <input value={value} type="text" onChange={(e)=>{setinput(e.target.value)}} />
        <Button onClick={handleclick} msg="add" />

        <div>
          {todo.map((item,index) => (
                  <div>  {item}
                  <button onClick={()=>deltetodo(index)} >delete</button>
                </div>              
         ))}
        </div>
        

    </>)
}

export default Todo