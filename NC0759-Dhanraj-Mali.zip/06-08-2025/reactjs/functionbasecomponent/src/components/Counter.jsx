
import { useState } from 'react';
import Button from './Button';
import Display from './Display';

function Counter() {
const [val,setval]= useState(0);

  return (
    <div className="App">
      <Display data={val} />

    <br />
     <div className='btn-grp'>
      
      <Button onClick={()=>{setval(val+1)}} msg="increament" />
      <Button onClick={()=>{setval(val-1)}} msg="decreament" />
      <Button onClick={()=>{setval(0)}} msg="reset" />
 
     </div>
    </div>
  );
}

export default Counter;
