import React, { useState } from "react";

class Color extends React.Component
{

    constructor()
    {
        super()
        this.state={
            colorname:'white'
        }
    }

    render(){

        return <div style={{backgroundColor:this.state.colorname,height:'50vh'}}>

            <button onClick={()=>{this.setState({colorname:'white'})}}>default</button>

            <button onClick={()=>{this.setState({colorname:'green'})}}>green</button>

            <button onClick={()=>{this.setState({colorname:'blue'})}}>blue</button>

            <button onClick={()=>{this.setState({colorname:'yellow'})}}>yellow</button>

            <button onClick={()=>{this.setState({colorname:'black'})}}>black</button>

            <button onClick={()=>{this.setState({colorname:'crimson'})}}>crimson</button>

            <button onClick={()=>{this.setState({colorname:'red'})}}>red</button>


        </div>
    }
}


export default Color