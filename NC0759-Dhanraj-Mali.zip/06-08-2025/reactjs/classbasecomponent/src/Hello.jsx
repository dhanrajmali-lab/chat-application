import React from "react";


class Hello extends React.Component{
    constructor(){
        super()
        this.state={
            count:0
        }
     
    }

    increament =()=>{
        this.setState({count: this.state.count+1})
    }
    decreament =()=>{
        this.setState({count:this.state.count-1})
    }
    
    render(){
        return <div style={{border:' 1px solid red', textAlign:'center',padding:'50px'}}>
            <h1>using class Component </h1>
            <h1>value is : {this.state.count}</h1>

            <button onClick={this.decreament}> - </button>
            <button onClick={this.increament}>+</button>
        </div>
    }
}


export default Hello