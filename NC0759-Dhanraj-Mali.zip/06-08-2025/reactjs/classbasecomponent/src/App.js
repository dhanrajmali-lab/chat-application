import './App.css';
import { useState } from 'react';
import Hello from './Hello';
import Color from './Color';


function App() {
  const [val,setval]=useState(0);
  return (
    <>
    <Color/>
    

    <div style={{border:' 1px solid red',textAlign:'center',padding:'50px'}}>
          <h1>using function component</h1>
          <h1>values is : {val}</h1>        
        <button onClick={()=>{setval(val-1)}}>-</button>
        <button onClick={()=>{setval(val+1)}}>+</button>
    </div>
        <Hello/>
    </>
  );
}

export default App;
