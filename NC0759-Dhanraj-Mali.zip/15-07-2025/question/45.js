const student = { 
    name: 'John',
    age: 20,
    hobbies: ['reading', 'games', 'coding'],
};

for(let x in student)
{
    console.log(`${x}:${student[x]}`)
}