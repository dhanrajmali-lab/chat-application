
const person={
    name:"raj",
    age:23,
    number:123456
}


delete person["number"];

delete person.age;

console.log(person.age);
console.log(person["number"])//deleted property print undefined

person["age"]=26;
console.log(person.age);

