

const date=new Date(2025, 6, 15, 9, 25, 30);


console.log(date.toDateString());
console.log(date.toLocaleTimeString())

