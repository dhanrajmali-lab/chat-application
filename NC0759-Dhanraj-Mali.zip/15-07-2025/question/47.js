const student={
    name:"raj",
    age:23,
    gender:"male",
    city:"gujrat"
}

let count=0;
for(let x in student)
{
    ++count;
}

console.log("counts of keys in object : "+count)