let str1="hello";
let str2="hello"


if(str1===str2)
{
    console.log("string is same")
}
else{
    console.log("string is not same")
}