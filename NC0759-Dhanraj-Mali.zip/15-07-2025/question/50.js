const msg="hello \n raj \n world";

console.log(msg)