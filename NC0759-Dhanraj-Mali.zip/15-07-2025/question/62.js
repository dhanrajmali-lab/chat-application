
const d=new Date(2000);
let year=d.getFullYear();


if(year%400==0 && n%4==0)
{
    console.log("this is leap year")
}
else{
    console.log("this is not leap year")
}
