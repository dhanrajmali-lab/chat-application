let str="red blue orange greeen";

let sbstr="orange";


if(str.includes(sbstr))
{
    console.log(`${sbstr} is substring `)
}
else{
    console.log(`${sbstr} is not  substring `)

}