
const person={
    name:"raj",
    age:23,
}

const key="name" in person;

if(key)
{
    console.log("the key is exsist in person object");
}
else{
    console.log("the key is not exist in person object")
}