
const number=200.254;

console.log(`$ ${number.toFixed(2)}`)



// program to format numbers as currency string
const formatter = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR'
});

console.log(formatter.format(2500));