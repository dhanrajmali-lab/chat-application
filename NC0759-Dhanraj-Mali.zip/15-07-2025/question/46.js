const student={
    name:"raj",
    age:22
}
const student1={
    class:"12th",
    gender:"male",
    city:"gujrat"
}

// first way using object.assign methods
const newobj1=Object.assign(student,student1);

for(let x in newobj1)
{
    console.log(`${x}:${newobj1[x]}`);
}

//second way using spread operator


console.log("*********************************")
const newobj2={...student,...student1};

for(let x in newobj2)
{
    console.log(`${x}:${newobj2[x]}`)
}
