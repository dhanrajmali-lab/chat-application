const characters ='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

let resualt="";
let len=6;
for(let i=0;i<len;i++)
{
    resualt+= characters.charAt(Math.floor(Math.random()*characters.length))
}
console.log(resualt)