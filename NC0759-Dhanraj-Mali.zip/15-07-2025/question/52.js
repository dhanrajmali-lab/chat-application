const str="hello world";

const check="he";

if(str.startsWith(check))
{
    console.log("string is start  with :"+check)
}
else{
    console.log("string is nor start with :"+check)
}