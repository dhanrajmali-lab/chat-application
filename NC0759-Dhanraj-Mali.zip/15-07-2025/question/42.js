
let str="hello world is inside univers"


console.log(str.startsWith("hello"))
console.log(str.startsWith("e"))


console.log(str.endsWith("univers"))
console.log(str.endsWith("rs"))

