const person={
    name:"raj",
    age:23
}


const copy=person;
//in this person object is copy in copy name vaiable but both are point same value and copy variable hav refrence for properties
console.log(copy.name)

const clone =Object.assign({},person);//object asign is also use for cloning for object

console.log(clone.name)