const student={
    name:"raj",
    age:23,
 }

    student[""]
    student.city="gujrat"
 

 
 for(let x in student)
 {
    console.log(`${x}:${student[x]}`)
 }