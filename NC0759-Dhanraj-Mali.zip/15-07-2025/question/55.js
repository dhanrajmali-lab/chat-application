const student={
    name:"raj",
    age:23,
    city:"gj"
}

const str= JSON.stringify(student);
``
console.log(str)