const str="hello raj hello raj"


console.log(str.replaceAll("hello","byy"))