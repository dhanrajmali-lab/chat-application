// program to encode a string to Base64
// defining the string
const str = "Learning JavaScript"; 

// encoding the string
const result = Window.btoa(str);
console.log(result);

// decoding the string
const result1 = Window.atob(result);
console.log(result1);