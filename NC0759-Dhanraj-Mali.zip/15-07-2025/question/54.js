let str="   hello world    "

console.log(str.trimStart())
console.log(str.trimEnd())
console.log(str.trim())
