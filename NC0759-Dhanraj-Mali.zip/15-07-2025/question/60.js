const str="hello \n world \n univers"
const result = str.replace(/(\n)/g, '<br>');

console.log(str)
console.log(result)
