let str="hello hello"

console.log(str.replaceAll('h',"H"));