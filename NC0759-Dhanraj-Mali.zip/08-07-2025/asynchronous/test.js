async function print() {
  console.log("1");

  await new Promise((resolve) => {
    setTimeout(() => {
      console.log("2");
      resolve();
    }, 1000);
  });

  console.log("3");
}

print();

console.log("1");

setTimeout( function print(){
    console.log("2");
    display()
},1000);

function display()
{
console.log("3")
}
