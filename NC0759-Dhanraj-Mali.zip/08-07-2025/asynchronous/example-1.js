
setTimeout(greeting,3000);//as a callback pass function and 3000 is milisecond in settimeoutfunction
//after 3 second greeting function is call
//settimeout this function is runing parallel
//greeting fn take 3 second for exucation but is not block any other exicution
// because setimeout is asynchronous 
function greeting()
{
    console.log("Hello World!!")
}

console.log("first");