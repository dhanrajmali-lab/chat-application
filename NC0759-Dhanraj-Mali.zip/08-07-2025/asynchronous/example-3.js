async function get() {
    try {
     const data= await fetch('https://fakestoreapi.com/products/1');

        let val= await data.json();
        console.log(val); 
    } catch (err) {
        console.log("Error:", err);
    }
}

get();