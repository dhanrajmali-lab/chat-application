
//custom promises
let promis= new Promise((resolve,reject)=>{

    let num=4;
     if(num%2==0)
     {
        resolve("even number")
     }
     else{
        reject("odd number")
     }
})

promis
.then((ms)=>{
    console.log("then part:"+ms);
})
.catch((er)=>{
    console.log("catch part:"+er);
})