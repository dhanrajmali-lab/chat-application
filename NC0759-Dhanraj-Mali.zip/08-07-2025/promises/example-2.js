 fetch("https://aareguru.existenz.ch/v2018/today?city=bern")//fetch always return a promise
    .then(res=>res.json())
    .then(json=>console.log(json))

.catch((err)=>{
    console.log("error",err);
})
.finally(
    console.log("work")
)
