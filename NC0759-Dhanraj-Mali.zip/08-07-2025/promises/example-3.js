// Create a Promise
const myPromise1 = new Promise((resolve, reject) => {
  setTimeout(resolve, 300, "King");
});

// Create another Promise
const myPromise2 = new Promise((resolve, reject) => {
  setTimeout(resolve, 100, "Queen");
});

//get any promis and print
Promise.any([myPromise1, myPromise2]).then((x) => {
  myDisplay(x);
}
);

//get all promis and print all
Promise.all([myPromise1, myPromise2]).then((x) => {
  myDisplay(x);
}
);


function myDisplay(s)
{
    console.log(s);
}