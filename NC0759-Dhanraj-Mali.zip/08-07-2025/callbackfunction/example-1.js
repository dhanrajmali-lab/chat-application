function display(some)
{
    console.log(some);
}

function sum(a,b,callback)
{
    let ans=a+b;

    callback(ans);
}

sum(5,5,display);