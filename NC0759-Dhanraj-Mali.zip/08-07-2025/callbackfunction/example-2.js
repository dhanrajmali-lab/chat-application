function display(some)
{
    console.log(some);
}


function hello(name,callback)
{
    let txt="hello:"+name;
    callback(txt);
}

function goodby(name, callback)
{
    let txt="goodbyy:"+name;
    callback(txt);
}

hello("raj",display);
goodby("raj",display)