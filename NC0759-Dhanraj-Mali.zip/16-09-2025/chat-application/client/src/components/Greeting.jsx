import React from 'react'

const Greeting = () => {
  return (
    <div style={{width:'100%'}}>
        
      <div className="heading" style={{height:'80vh', display:'flex',justifyContent:'center', alignItems:'center'}}>
              <h1>Welcome</h1>
            </div>

    </div>
  )
}

export default Greeting